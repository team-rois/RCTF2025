from flask import Flask, render_template, request, jsonify, session
import time
import secrets
import os
import argparse
import re

app = Flask(__name__)
# 使用环境变量或生成随机密钥，确保安全性
app.secret_key = os.environ.get('SECRET_KEY', secrets.token_hex(32))

# 安全配置
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24小时

# 正确答案（后端预定义，仅存储RCTF{}包裹的内容）
CORRECT_ANSWERS = {
    'challenge1': 'spawn whoami',
    'challenge2': '10',
    'challenge3': 'Intel64 Family 6 Model 191 Stepping 2, GenuineIntel',
    'challenge4': 'TscanPlus'
}

# 固定flag（CTF格式）
FIXED_FLAG = "RCTF{Wh1l3_Th0r_Struck_L1ghtn1ng_L0k1_St0l3_Th3_Thr0n3}"

# 挑战内容（仅后端存储，不暴露在前端HTML中）
CHALLENGES = {
    'challenge1': {
        'title': 'Challenge 1: The First Command',
        'question': 'After successfully infiltrating Thor\'s machine, Loki\'s agent came to life. Like all beginnings, the first action reveals intent.<br><br>Hidden among thousands of scanning requests and server responses, Loki issued his opening move—the first command that set his plan in motion.<br><br><strong>Question:</strong> What was the first command Loki executed after his agent established connection?<br><br><strong>Flag Format:</strong> complete_command (The exact command Loki sent to the agent)'
    },
    'challenge2': {
        'title': 'Challenge 2: The Heartbeat',
        'question': 'Thor\'s attacks were chaotic—random intervals, sporadic bursts, the rhythm of fury. But Loki\'s agent operated with cold precision.<br><br>Buried in the noise, the agent sent regular heartbeats back to its master, each pulse proving it remained alive and obedient. These signals followed a steady cadence, mechanical and unwavering.<br><br>Find the pattern. Find the pulse.<br><br><strong>Question:</strong> How many seconds passed between each heartbeat of Loki\'s agent?<br><br><strong>Flag Format:</strong> integer (e.g., 30)'
    },
    'challenge3': {
        'title': 'Challenge 3: The Heart of Iron',
        'question': '"Every warrior has a heart that drives them. For mortals, it beats with blood. For machines, it pulses with silicon and electricity. Loki, ever curious, sought to know the very core of Thor\'s weapon—the processor that powers his digital fortress."<br><br>During his infiltration, Loki commanded his agent to enumerate the environment, cataloging every detail of Thor\'s system. Among the mundane variables and paths, one piece of information reveals the machine\'s very identity—its processor, the beating heart of computation.<br><br>Like a smith examining the forge that created a sword, Loki identified the specific metal and make of Thor\'s processor.<br><br><strong>Question:</strong> What processor model powers Thor\'s machine?<br><br><strong>Flag Format:</strong> Complete_Processor_Model_String (e.g., Intel64 Family 6 Model 85 Stepping 4, GenuineIntel'
    },
    'challenge4': {
        'title': 'Challenge 4: Odin\'s Eye',
        'question': '"Odin sacrificed his eye to drink from Mimir\'s well and gain wisdom. Loki needs no such sacrifice—he simply steals the sight of others."<br><br>In the final moments before vanishing, Loki commanded his agent to capture what Thor\'s own eyes were seeing—a snapshot of the screen, frozen in time. Within this stolen image lies evidence of Thor\'s own weapons, the very tools he was using to hunt Loki.<br><br>The irony is exquisite: Thor\'s scanner, visible on his own screen, was documented by the very enemy he sought to find.<br><br><strong>Question:</strong> According to the screenshot Loki exfiltrated, which vulnerability scanning tool was Thor running at that moment?<br><br><strong>Flag Format:</strong> ToolGithubRepoName (e.g., if the tool\'s repository is https://github.com/user/AwesomeTool, answer AwesomeTool)'
    }
}

# Anti-bruteforce: Track submission count and time for each IP
ip_attempts = {}

def check_rate_limit(ip):
    """Check IP submission rate limit"""
    current_time = time.time()
    if ip not in ip_attempts:
        ip_attempts[ip] = {'count': 1, 'reset_time': current_time + 60}
        return True
    
    # Reset count if over 1 minute
    if current_time > ip_attempts[ip]['reset_time']:
        ip_attempts[ip] = {'count': 1, 'reset_time': current_time + 60}
        return True
    
    # Limit if more than 10 submissions within 1 minute
    if ip_attempts[ip]['count'] >= 10:
        return False
    
    ip_attempts[ip]['count'] += 1
    return True

def normalize_answer(answer):
    """Normalize answer (trim whitespace only, user submits pure content without RCTF{})"""
    if not isinstance(answer, str):
        return ''
    # 只移除首尾空白，用户直接提交纯内容（不需要RCTF{}包裹）
    return answer.strip()

def validate_challenge1(answer):
    """Validate challenge 1 answer (First Command)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge1'])
    user_answer = normalize_answer(answer)
    return user_answer == correct

def validate_challenge2(answer):
    """Validate challenge 2 answer (Heartbeat interval)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge2'])
    user_answer = normalize_answer(answer)
    return user_answer == correct

def validate_challenge3(answer):
    """Validate challenge 3 answer (Processor model)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge3'])
    user_answer = normalize_answer(answer)
    return user_answer == correct

def validate_challenge4(answer):
    """Validate challenge 4 answer (Vulnerability scanning tool)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge4'])
    user_answer = normalize_answer(answer)
    return user_answer == correct


def get_flag():
    """返回固定的CTF格式flag"""
    return FIXED_FLAG

def init_user_session():
    """初始化用户session，确保每个用户有独立状态"""
    if 'completed_challenges' not in session:
        session['completed_challenges'] = []
        session['session_id'] = secrets.token_hex(16)
    if 'session_id' not in session:
        session['session_id'] = secrets.token_hex(16)
    # 防止session固定攻击：每次请求都重新生成session ID（如果session是新的）
    session.permanent = True

def validate_input_length(text, max_length=1000):
    """验证输入长度，防止DoS攻击"""
    if not isinstance(text, str):
        return False
    # 检查字符串长度，防止超长输入导致DoS
    if len(text) > max_length:
        return False
    # 检查是否包含控制字符（除了常见的空白字符）
    if any(ord(c) < 32 and c not in '\t\n\r' for c in text):
        return False
    return True

def check_challenge_order(challenge, completed):
    """检查挑战是否按顺序完成"""
    challenge_num = int(challenge.replace('challenge', ''))
    # 检查前面的挑战是否都已完成
    for i in range(1, challenge_num):
        if f'challenge{i}' not in completed:
            return False
    return True

@app.route('/')
def index():
    """主页，初始化用户session"""
    init_user_session()
    # 传递用户已完成的挑战给前端
    completed = session.get('completed_challenges', [])
    has_flag = len(completed) >= 4
    flag = None
    if has_flag:
        flag = get_flag()
    # 只传递第一个挑战的内容，其他挑战通过API动态加载
    current_challenge = CHALLENGES['challenge1'] if 'challenge1' not in completed else None
    return render_template('index.html', 
                         completed_challenges=completed, 
                         flag=flag,
                         current_challenge=current_challenge)

@app.route('/submit', methods=['POST'])
def submit():
    """提交答案，验证并更新用户状态"""
    # 初始化session
    init_user_session()
    
    # Get IP address (注意：X-Forwarded-For可以被伪造，仅用于速率限制)
    ip = request.remote_addr
    if request.headers.get('X-Forwarded-For'):
        # 取第一个IP（可能是代理链中的第一个）
        ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()
    # 基本IP格式验证（防止注入）
    if not ip or len(ip) > 45:  # IPv6最大长度
        ip = 'unknown'
    
    # Check rate limit
    if not check_rate_limit(ip):
        return jsonify({
            'success': False,
            'message': 'Too many requests, please try again later'
        }), 429
    
    data = request.get_json()
    if not data:
        return jsonify({
            'success': False,
            'message': 'Invalid request format'
        }), 400
    
    challenge = data.get('challenge')
    
    if not challenge or challenge not in ['challenge1', 'challenge2', 'challenge3', 'challenge4']:
        return jsonify({
            'success': False,
            'message': 'Invalid challenge'
        }), 400
    
    # 检查是否已经完成该挑战
    completed = session.get('completed_challenges', [])
    if challenge in completed:
        return jsonify({
            'success': False,
            'message': 'This challenge has already been completed'
        }), 400
    
    # 检查挑战顺序，确保按顺序完成
    if not check_challenge_order(challenge, completed):
        return jsonify({
            'success': False,
            'message': 'Please complete challenges in order'
        }), 400
    
    # 验证答案
    is_correct = False
    
    if challenge == 'challenge1':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge1(answer)
    
    elif challenge == 'challenge2':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge2(answer)
    
    elif challenge == 'challenge3':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer, 100):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge3(answer)
    
    elif challenge == 'challenge4':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer, 200):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge4(answer)
    
    if is_correct:
        # 标记挑战为已完成
        if challenge not in completed:
            completed.append(challenge)
            session['completed_challenges'] = completed
        
        # 检查是否完成所有挑战
        all_completed = len(completed) >= 4
        flag = None
        if all_completed:
            flag = get_flag()
        
        return jsonify({
            'success': True,
            'message': 'Correct answer!',
            'all_completed': all_completed,
            'flag': flag
        })
    else:
        return jsonify({
            'success': False,
            'message': 'Incorrect answer, please try again'
        }), 400

@app.route('/status', methods=['GET'])
def get_status():
    """获取用户当前解题状态"""
    init_user_session()
    completed = session.get('completed_challenges', [])
    all_completed = len(completed) >= 4
    flag = None
    if all_completed:
        flag = get_flag()
    return jsonify({
        'completed_challenges': completed,
        'all_completed': all_completed,
        'flag': flag
    })

@app.route('/challenge/<challenge_id>', methods=['GET'])
def get_challenge(challenge_id):
    """获取指定挑战的内容（仅返回用户应该看到的挑战）"""
    init_user_session()
    completed = session.get('completed_challenges', [])
    
    # 验证挑战ID格式
    if challenge_id not in CHALLENGES:
        return jsonify({
            'success': False,
            'message': 'Invalid challenge'
        }), 404
    
    # 检查用户是否有权限查看该挑战
    challenge_num = int(challenge_id.replace('challenge', ''))
    # 用户只能查看第一个挑战，或者已经完成的挑战，或者下一个应该解锁的挑战
    if challenge_num == 1:
        # 第一个挑战总是可见
        pass
    elif challenge_id in completed:
        # 已完成的挑战可见
        pass
    elif challenge_num == len(completed) + 1:
        # 下一个应该解锁的挑战可见
        pass
    else:
        # 其他挑战不可见
        return jsonify({
            'success': False,
            'message': 'Challenge not available yet'
        }), 403
    
    challenge_data = CHALLENGES[challenge_id].copy()
    challenge_data['is_completed'] = challenge_id in completed
    return jsonify({
        'success': True,
        'challenge': challenge_data
    })

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Asgard Fallen Down CTF Platform')
    parser.add_argument('--port', type=int, default=5000, help='Port to run the server on')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='Host to bind to')
    args = parser.parse_args()
    
    # 关闭debug模式，确保生产环境安全
    app.run(debug=False, port=args.port, host=args.host)
