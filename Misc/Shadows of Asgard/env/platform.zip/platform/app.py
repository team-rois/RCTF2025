from flask import Flask, render_template, request, jsonify, session
import time
import secrets
import os
import argparse
import re

app = Flask(__name__)
# 使用环境变量或生成随机密钥，确保安全性
app.secret_key = os.environ.get('SECRET_KEY', secrets.token_hex(32))

# 安全配置
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24小时

# 正确答案（后端预定义，不从文件读取）
CORRECT_ANSWERS = {
    'challenge1': '渊恒科技',
    'challenge2': 'C:\\\\Users\\\\dell\\\\Desktop\\\\Microsoft VS Code\\\\Code.exe',  # 存储为双反斜杠格式
    'challenge3': 'c0c6125e',
    'challenge4': '2018-09-14 23:09:26',
    'challenge5': 'RCTF{they always say Raven is inauspicious}'
}

# 固定flag（CTF格式）
FIXED_FLAG = "RCTF{Wh3n_Th3_R4v3n_S1ngs_4sg4rd_F4lls_S1l3nt}"

# Anti-bruteforce: Track submission count and time for each IP
ip_attempts = {}

def check_rate_limit(ip):
    """Check IP submission rate limit"""
    current_time = time.time()
    if ip not in ip_attempts:
        ip_attempts[ip] = {'count': 1, 'reset_time': current_time + 60}
        return True
    
    # Reset count if over 1 minute
    if current_time > ip_attempts[ip]['reset_time']:
        ip_attempts[ip] = {'count': 1, 'reset_time': current_time + 60}
        return True
    
    # Limit if more than 10 submissions within 1 minute
    if ip_attempts[ip]['count'] >= 10:
        return False
    
    ip_attempts[ip]['count'] += 1
    return True

def normalize_answer(answer):
    """Normalize answer (trim whitespace, normalize case, etc.)"""
    if isinstance(answer, str):
        return answer.strip()
    return answer

def validate_challenge1(answer):
    """Validate challenge 1 answer (Company name)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge1'])
    user_answer = normalize_answer(answer)
    return user_answer == correct

def validate_challenge2(answer):
    """Validate challenge 2 answer (File path)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge2'])
    user_answer = normalize_answer(answer)
    return user_answer == correct

def validate_challenge3(answer):
    """Validate challenge 3 answer (Task ID)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge3'])
    user_answer = normalize_answer(answer)
    return user_answer.lower() == correct.lower()

def validate_challenge4(answer):
    """Validate challenge 4 answer (Drive creation time)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge4'])
    user_answer = normalize_answer(answer)
    return user_answer == correct

def validate_challenge5(answer):
    """Validate challenge 5 answer (Hidden message)"""
    correct = normalize_answer(CORRECT_ANSWERS['challenge5'])
    user_answer = normalize_answer(answer)
    return user_answer == correct


def get_flag():
    """返回固定的CTF格式flag"""
    return FIXED_FLAG

def init_user_session():
    """初始化用户session，确保每个用户有独立状态"""
    if 'completed_challenges' not in session:
        session['completed_challenges'] = []
        session['session_id'] = secrets.token_hex(16)
    if 'session_id' not in session:
        session['session_id'] = secrets.token_hex(16)
    # 防止session固定攻击：每次请求都重新生成session ID（如果session是新的）
    session.permanent = True

def validate_input_length(text, max_length=1000):
    """验证输入长度，防止DoS攻击"""
    if not isinstance(text, str):
        return False
    return len(text) <= max_length

def check_challenge_order(challenge, completed):
    """检查挑战是否按顺序完成"""
    challenge_num = int(challenge.replace('challenge', ''))
    # 检查前面的挑战是否都已完成
    for i in range(1, challenge_num):
        if f'challenge{i}' not in completed:
            return False
    return True

@app.route('/')
def index():
    """主页，初始化用户session"""
    init_user_session()
    # 传递用户已完成的挑战给前端
    completed = session.get('completed_challenges', [])
    has_flag = len(completed) >= 5
    flag = None
    if has_flag:
        flag = get_flag()
    return render_template('index.html', completed_challenges=completed, flag=flag)

@app.route('/submit', methods=['POST'])
def submit():
    """提交答案，验证并更新用户状态"""
    # 初始化session
    init_user_session()
    
    # Get IP address
    ip = request.remote_addr
    if request.headers.get('X-Forwarded-For'):
        ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()
    
    # Check rate limit
    if not check_rate_limit(ip):
        return jsonify({
            'success': False,
            'message': 'Too many requests, please try again later'
        }), 429
    
    data = request.get_json()
    if not data:
        return jsonify({
            'success': False,
            'message': 'Invalid request format'
        }), 400
    
    challenge = data.get('challenge')
    
    if not challenge or challenge not in ['challenge1', 'challenge2', 'challenge3', 'challenge4', 'challenge5']:
        return jsonify({
            'success': False,
            'message': 'Invalid challenge'
        }), 400
    
    # 检查是否已经完成该挑战
    completed = session.get('completed_challenges', [])
    if challenge in completed:
        return jsonify({
            'success': False,
            'message': 'This challenge has already been completed'
        }), 400
    
    # 检查挑战顺序，确保按顺序完成
    if not check_challenge_order(challenge, completed):
        return jsonify({
            'success': False,
            'message': 'Please complete challenges in order'
        }), 400
    
    # 验证答案
    is_correct = False
    
    if challenge == 'challenge1':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge1(answer)
    
    elif challenge == 'challenge2':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        # 调试：打印接收到的答案和正确答案
        print(f"DEBUG - Received answer: {repr(answer)}")
        print(f"DEBUG - Correct answer: {repr(CORRECT_ANSWERS['challenge2'])}")
        is_correct = validate_challenge2(answer)
    
    elif challenge == 'challenge3':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer, 100):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge3(answer)
    
    elif challenge == 'challenge4':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer, 100):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge4(answer)
    
    elif challenge == 'challenge5':
        answer = data.get('answer', '').strip()
        if not answer:
            return jsonify({
                'success': False,
                'message': 'Please provide an answer'
            }), 400
        if not validate_input_length(answer, 200):
            return jsonify({
                'success': False,
                'message': 'Answer too long'
            }), 400
        is_correct = validate_challenge5(answer)
    
    if is_correct:
        # 标记挑战为已完成
        if challenge not in completed:
            completed.append(challenge)
            session['completed_challenges'] = completed
        
        # 检查是否完成所有挑战
        all_completed = len(completed) >= 5
        flag = None
        if all_completed:
            flag = get_flag()
        
        return jsonify({
            'success': True,
            'message': 'Correct answer!',
            'all_completed': all_completed,
            'flag': flag
        })
    else:
        return jsonify({
            'success': False,
            'message': 'Incorrect answer, please try again'
        }), 400

@app.route('/status', methods=['GET'])
def get_status():
    """获取用户当前解题状态"""
    init_user_session()
    completed = session.get('completed_challenges', [])
    all_completed = len(completed) >= 5
    flag = None
    if all_completed:
        flag = get_flag()
    return jsonify({
        'completed_challenges': completed,
        'all_completed': all_completed,
        'flag': flag
    })

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Shadows of Asgard CTF Platform')
    parser.add_argument('--port', type=int, default=5000, help='Port to run the server on')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='Host to bind to')
    args = parser.parse_args()
    
    # 关闭debug模式，确保生产环境安全
    app.run(debug=False, port=args.port, host=args.host)
