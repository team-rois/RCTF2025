.. _superseded:

******************
Superseded Modules
******************

The modules described in this chapter are deprecated and only kept for
backwards compatibility. They have been superseded by other modules.


.. toctree::
   :maxdepth: 1

   aifc.rst
   audioop.rst
   cgi.rst
   cgitb.rst
   chunk.rst
   crypt.rst
   imghdr.rst
   mailcap.rst
   msilib.rst
   nis.rst
   nntplib.rst
   optparse.rst
   ossaudiodev.rst
   pipes.rst
   sndhdr.rst
   spwd.rst
   sunau.rst
   telnetlib.rst
   uu.rst
   xdrlib.rst
