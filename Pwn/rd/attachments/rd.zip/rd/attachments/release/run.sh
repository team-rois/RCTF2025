#!/bin/sh
exec stdbuf -i0 -o0 -e0 ./main
