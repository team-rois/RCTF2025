#include "aes.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

// ---- S-box ----
static const uint8_t sbox[256] = {
  0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
  0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
  0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
  0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
  0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
  0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
  0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
  0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
  0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
  0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
  0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
  0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
  0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
  0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
  0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
  0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

// inverse sbox
static uint8_t inv_sbox[256];
static const uint8_t Rcon[11] = {0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1B,0x36};

static inline uint8_t xtime(uint8_t a) {
    return (uint8_t)((a << 1) ^ ((a & 0x80) ? 0x1B : 0x00));
}
static uint8_t gm_mul(uint8_t a, uint8_t b) {
    uint8_t res = 0;
    while (b) {
        if (b & 1) res ^= a;
        a = xtime(a);
        b >>= 1;
    }
    return res;
}

static void sub_bytes(uint8_t state[16]) {
    for (int i = 0; i < 16; i++) state[i] = sbox[state[i]];
}
static void inv_sub_bytes(uint8_t state[16]) {
    for (int i = 0; i < 16; i++) state[i] = inv_sbox[state[i]];
}

static void shift_rows(uint8_t state[16]) {
    uint8_t tmp[16];
    memcpy(tmp, state, 16);
    // row0
    state[0]  = tmp[0];
    state[4]  = tmp[4];
    state[8]  = tmp[8];
    state[12] = tmp[12];
    // row1
    state[1]  = tmp[5];
    state[5]  = tmp[9];
    state[9]  = tmp[13];
    state[13] = tmp[1];
    // row2
    state[2]  = tmp[10];
    state[6]  = tmp[14];
    state[10] = tmp[2];
    state[14] = tmp[6];
    // row3
    state[3]  = tmp[15];
    state[7]  = tmp[3];
    state[11] = tmp[7];
    state[15] = tmp[11];
}

static void inv_shift_rows(uint8_t state[16]) {
    uint8_t tmp[16];
    memcpy(tmp, state, 16);
    state[0]  = tmp[0];
    state[4]  = tmp[4];
    state[8]  = tmp[8];
    state[12] = tmp[12];
    state[1]  = tmp[13];
    state[5]  = tmp[1];
    state[9]  = tmp[5];
    state[13] = tmp[9];
    state[2]  = tmp[10];
    state[6]  = tmp[14];
    state[10] = tmp[2];
    state[14] = tmp[6];
    state[3]  = tmp[7];
    state[7]  = tmp[11];
    state[11] = tmp[15];
    state[15] = tmp[3];
}

static void mix_columns(uint8_t state[16]) {
    for (int c = 0; c < 4; c++) {
        int i = c * 4;
        uint8_t a0 = state[i], a1 = state[i+1], a2 = state[i+2], a3 = state[i+3];
        uint8_t r0 = (uint8_t)(gm_mul(a0,2) ^ gm_mul(a1,3) ^ a2 ^ a3);
        uint8_t r1 = (uint8_t)(a0 ^ gm_mul(a1,2) ^ gm_mul(a2,3) ^ a3);
        uint8_t r2 = (uint8_t)(a0 ^ a1 ^ gm_mul(a2,2) ^ gm_mul(a3,3));
        uint8_t r3 = (uint8_t)(gm_mul(a0,3) ^ a1 ^ a2 ^ gm_mul(a3,2));
        state[i]=r0; state[i+1]=r1; state[i+2]=r2; state[i+3]=r3;
    }
}

static void inv_mix_columns(uint8_t state[16]) {
    for (int c = 0; c < 4; c++) {
        int i = c * 4;
        uint8_t a0 = state[i], a1 = state[i+1], a2 = state[i+2], a3 = state[i+3];
        uint8_t r0 = (uint8_t)(gm_mul(a0,0x0E) ^ gm_mul(a1,0x0B) ^ gm_mul(a2,0x0D) ^ gm_mul(a3,0x09));
        uint8_t r1 = (uint8_t)(gm_mul(a0,0x09) ^ gm_mul(a1,0x0E) ^ gm_mul(a2,0x0B) ^ gm_mul(a3,0x0D));
        uint8_t r2 = (uint8_t)(gm_mul(a0,0x0D) ^ gm_mul(a1,0x09) ^ gm_mul(a2,0x0E) ^ gm_mul(a3,0x0B));
        uint8_t r3 = (uint8_t)(gm_mul(a0,0x0B) ^ gm_mul(a1,0x0D) ^ gm_mul(a2,0x09) ^ gm_mul(a3,0x0E));
        state[i]=r0; state[i+1]=r1; state[i+2]=r2; state[i+3]=r3;
    }
}

static void add_round_key(uint8_t state[16], const uint8_t roundkey[16]) {
    for (int i = 0; i < 16; i++) state[i] ^= roundkey[i];
}

// key expansion: expands 16-byte key -> 11 round keys of 16 bytes
static void key_expansion(const uint8_t key[16], uint8_t round_keys[11][16]) {
    uint32_t w[44];
    for (int i = 0; i < 4; i++) {
        w[i] = ((uint32_t)key[4*i] << 24) | ((uint32_t)key[4*i+1] << 16) | ((uint32_t)key[4*i+2] << 8) | (uint32_t)key[4*i+3];
    }
    for (int i = 4; i < 44; i++) {
        uint32_t temp = w[i-1];
        if (i % 4 == 0) {
            // RotWord
            temp = ((temp << 8) & 0xFFFFFFFF) | ((temp >> 24) & 0xFF);
            // SubWord
            uint32_t b0 = sbox[(temp >> 24) & 0xFF];
            uint32_t b1 = sbox[(temp >> 16) & 0xFF];
            uint32_t b2 = sbox[(temp >> 8) & 0xFF];
            uint32_t b3 = sbox[temp & 0xFF];
            temp = (b0 << 24) | (b1 << 16) | (b2 << 8) | b3;
            temp ^= ((uint32_t)Rcon[i/4] << 24);
        }
        w[i] = w[i - 4] ^ temp;
    }
    for (int r = 0; r < 11; r++) {
        for (int j = 0; j < 4; j++) {
            uint32_t word = w[r*4 + j];
            round_keys[r][4*j + 0] = (word >> 24) & 0xFF;
            round_keys[r][4*j + 1] = (word >> 16) & 0xFF;
            round_keys[r][4*j + 2] = (word >> 8) & 0xFF;
            round_keys[r][4*j + 3] = word & 0xFF;
        }
    }
}

static void aes_encrypt_block(const uint8_t in[16], uint8_t out[16], const uint8_t round_keys[11][16]) {
    uint8_t state[16];
    memcpy(state, in, 16);
    add_round_key(state, round_keys[0]);
    for (int r = 1; r <= 9; r++) {
        sub_bytes(state);
        shift_rows(state);
        mix_columns(state);
        add_round_key(state, round_keys[r]);
    }
    // final round
    sub_bytes(state);
    shift_rows(state);
    add_round_key(state, round_keys[10]);
    memcpy(out, state, 16);
}

static void aes_decrypt_block(const uint8_t in[16], uint8_t out[16], const uint8_t round_keys[11][16]) {
    uint8_t state[16];
    memcpy(state, in, 16);
    add_round_key(state, round_keys[10]);
    inv_shift_rows(state);
    inv_sub_bytes(state);
    for (int r = 9; r >= 1; r--) {
        add_round_key(state, round_keys[r]);
        inv_mix_columns(state);
        inv_shift_rows(state);
        inv_sub_bytes(state);
    }
    add_round_key(state, round_keys[0]);
    memcpy(out, state, 16);
}

// PKCS7 helpers
static uint8_t* pkcs7_pad(const uint8_t *in, size_t in_len, size_t block_size, size_t *out_len) {
    size_t pad = block_size - (in_len % block_size);
    if (pad == 0) pad = block_size;
    *out_len = in_len + pad;
    uint8_t *out = (uint8_t*)malloc(*out_len);
    if (!out) return NULL;
    memcpy(out, in, in_len);
    memset(out + in_len, (uint8_t)pad, pad);
    return out;
}
static uint8_t* pkcs7_unpad(uint8_t *in_out, size_t in_len, size_t block_size, size_t *out_len) {
    if (in_len == 0 || (in_len % block_size) != 0) return NULL;
    uint8_t pad = in_out[in_len - 1];
    if (pad == 0 || pad > block_size) return NULL;
    for (size_t i = 0; i < pad; i++) if (in_out[in_len - 1 - i] != pad) return NULL;
    *out_len = in_len - pad;
    uint8_t *res = (uint8_t*)malloc(*out_len);
    if (!res) return NULL;
    memcpy(res, in_out, *out_len);
    return res;
}

// public APIs
uint8_t* aes_encrypt_ecb(const uint8_t *plaintext, size_t len, const uint8_t key[AES_KEY_SIZE], size_t *out_len) {
    // build inv_sbox once
    static int inv_init = 0;
    if (!inv_init) {
        for (int i = 0; i < 256; i++) inv_sbox[sbox[i]] = (uint8_t)i;
        inv_init = 1;
    }

    size_t padded_len;
    uint8_t *padded = pkcs7_pad(plaintext, len, AES_BLOCK_SIZE, &padded_len);
    if (!padded) return NULL;
    uint8_t *out = (uint8_t*)malloc(padded_len);
    if (!out) { free(padded); return NULL; }

    uint8_t round_keys[11][16];
    key_expansion(key, round_keys);

    for (size_t off = 0; off < padded_len; off += 16) {
        aes_encrypt_block(padded + off, out + off, round_keys);
    }

    free(padded);
    *out_len = padded_len;
    return out;
}

uint8_t* aes_decrypt_ecb(const uint8_t *ciphertext, size_t len, const uint8_t key[AES_KEY_SIZE], size_t *out_len) {
    if ((len % AES_BLOCK_SIZE) != 0) return NULL;
    static int inv_init = 0;
    if (!inv_init) {
        for (int i = 0; i < 256; i++) inv_sbox[sbox[i]] = (uint8_t)i;
        inv_init = 1;
    }

    uint8_t *buf = (uint8_t*)malloc(len);
    if (!buf) return NULL;
    memcpy(buf, ciphertext, len);
    uint8_t round_keys[11][16];
    key_expansion(key, round_keys);

    for (size_t off = 0; off < len; off += 16) {
        aes_decrypt_block(buf + off, buf + off, round_keys);
    }
    uint8_t *unpadded = pkcs7_unpad(buf, len, AES_BLOCK_SIZE, out_len);
    free(buf);
    return unpadded;
}
