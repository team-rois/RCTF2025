#ifndef AES_H
#define AES_H

#include <stdint.h>
#include <stddef.h>

#define AES_BLOCK_SIZE 16
#define AES_KEY_SIZE 16

// AES-128 ECB encrypt/decrypt with PKCS#7 padding
uint8_t* aes_encrypt_ecb(const uint8_t *plaintext, size_t len, const uint8_t key[AES_KEY_SIZE], size_t *out_len);
uint8_t* aes_decrypt_ecb(const uint8_t *ciphertext, size_t len, const uint8_t key[AES_KEY_SIZE], size_t *out_len);

#endif // AES_H
