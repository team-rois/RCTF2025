#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

typedef enum {
    CTL_STATE_NONE = 0,
    CTL_STATE_RECORD,
    CTL_STATE_FINISH
} ctl_state_t;

typedef enum {
    CTL_CHECK_NO = 0,
    CTL_CHECK_PASS,
    CTL_CHECK_FAILED
} ctl_check_t;

typedef struct {
    ctl_state_t state;
    ctl_check_t check;
    long long sum;                  // 当前求和（用于 target_sum 比较）
    int last_block_id;         // 记录上一个访问的 block id
    int step_index;            // 用来遍历输入路径的索引
    int path_buf[256];        // 记录被“需要记录”的值序列（用于 hash）
    int path_buf_len;
} Controller;

/* ----------------------------- 示例静态数据 -----------------------------
 * 说明：你应当替换这些数据为你的题目数据
 * edges[block_id][0] = next block id for left (dir bit == 0)
 * edges[block_id][1] = next block id for right (dir bit == 1)
 * 如果为 -1 表示到叶子
 */
// #define MAX_BLOCKS 16