#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
// #include <sys/mman.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <errno.h>

#include "global_hdr.h"
#include "tea.h"
#include "aes.h"

#define FLAG_LEN 17
// #define MAX_BLOCKS 32

char g_path_data[1024];
int path_len = 0;
int current_index = 0;

unsigned char g_flags[FLAG_LEN];
int target_sum = 3;
int current_sum = 0;
// xor 0xff
unsigned char g_code_key[] = {0xb5,0x8a,0x92,0x8f,0xa0,0x97,0xce,0x98,0x97,0xa0,0xcd,0xa0,0x8c,0x94,0x86,0xde};
unsigned char g_edge_key[] = {0xb3,0xce,0x91,0x94,0xa0,0xcd,0xa0,0x8b,0x97,0xcc,0xa0,0xb6,0xb1,0xcc,0xab,0xde};

uint64_t fnv1a_hash(const int *data, size_t len) {
    const uint64_t FNV_prime = 1099511628211ULL;
    uint64_t hash = 1469598103934665603ULL;

    for (size_t i = 0; i < len; i++) {
        hash ^= (uint64_t)data[i];
        hash *= FNV_prime;
    }

    return hash;
}

void error_exit(const char *msg) {
    // fprintf(stderr, "[Error] %s\n", msg);
    exit(1);
}

void load_path_file(const char *filename) {
    FILE *f = fopen(filename, "r");
    if (!f) error_exit("could not open file");

    int c;
    int i = 0;
    while ((c = fgetc(f)) != EOF && i < (int)sizeof(g_path_data) - 1) {
        if (c == '\n' || c == '\r') continue;
        if (!isdigit(c)) {
            error_exit("path file contains invalid characters");
        }
        g_path_data[i++] = (char)c;
    }
    g_path_data[i] = '\0';
    fclose(f);
    path_len = i;

    if (path_len == 0) {
        error_exit("path file is empty");
    }
}

// ---------------------------
// Step 2: 读取 flag
// ---------------------------
void load_flag() {
    char buf[256];
    printf(" input flag: ");
    if (!fgets(buf, sizeof(buf), stdin)) {
        error_exit("error load flag");
    }

    buf[strcspn(buf, "\r\n")] = '\0';

    if (strlen(buf) != FLAG_LEN) {
        error_exit("error load flag");
    }

    for (int i = 0; i < FLAG_LEN; i++) {
        unsigned char c = buf[i];
        if (c < 32 || c > 127) {
            error_exit("error load flag");
        }
        g_flags[i] = c;
    }
}

// int EdgeBlock() {
//     if (current_index < path_len) {
//         int bid = g_path_data[current_index++] - '0';
//         return bid;
//     }
//     return -1; // 结束
// }


// typedef int (*BlockFunc)(void);
// BlockFunc CodeBlock[MAX_BLOCKS] = {block0, block1, block2};
extern void* g_edges[];
extern unsigned long g_edges_len[];
extern void* announce[];
extern unsigned long announce_len[];

extern unsigned long long g_target_sum;
// ---------------------------
// 主逻辑循环
// ---------------------------
typedef int (*CodeFunc)(Controller* control, unsigned char flags[]);
typedef int (*EdgeFunc)(Controller* control, int current_block_id, uint8_t s);


int execute_code(const unsigned char *decrypted, size_t len,
                                Controller *ctrl, unsigned char flags[])
{
    if (!decrypted) return -1;
    if (len == 0) return -2;

    unsigned char *tmp = (unsigned char*)malloc(len);
    if (!tmp) return -3;
    memcpy(tmp, decrypted, len);

    long pagesz = sysconf(_SC_PAGESIZE);
    if (pagesz <= 0) pagesz = 4096;
    size_t alloc_len = ((len + (size_t)pagesz - 1) / (size_t)pagesz) * (size_t)pagesz;

    void *mem = mmap(NULL, alloc_len, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        free(tmp);
        return -4;
    }

    memcpy(mem, tmp, len);

    if (mprotect(mem, alloc_len, PROT_READ | PROT_EXEC) != 0) {
        if (mprotect(mem, alloc_len, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
            munmap(mem, alloc_len);
            free(tmp);
            return -5;
        }
    }

    CodeFunc fn = (CodeFunc)mem;

    int result = 0;
    result = fn(ctrl, flags);

    if (mprotect(mem, alloc_len, PROT_READ | PROT_WRITE) != 0) {

    }

    memset(mem, 0, alloc_len);
    munmap(mem, alloc_len);

    free(tmp);

    return result;
}


int execute_edge(const unsigned char *decrypted, size_t len,
                                Controller* control, int current_block_id, uint8_t s)
{
    if (!decrypted) return -1;
    if (len == 0) return -2;

    unsigned char *tmp = (unsigned char*)malloc(len);
    if (!tmp) return -3;
    memcpy(tmp, decrypted, len);

    long pagesz = sysconf(_SC_PAGESIZE);
    if (pagesz <= 0) pagesz = 4096;
    size_t alloc_len = ((len + (size_t)pagesz - 1) / (size_t)pagesz) * (size_t)pagesz;

    void *mem = mmap(NULL, alloc_len, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        free(tmp);
        return -4;
    }

    memcpy(mem, tmp, len);

    if (mprotect(mem, alloc_len, PROT_READ | PROT_EXEC) != 0) {
        if (mprotect(mem, alloc_len, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
            munmap(mem, alloc_len);
            free(tmp);
            return -5;
        }
    }

    EdgeFunc fn = (EdgeFunc)mem;

    int result = 0;
    result = fn(control, current_block_id, s);

    if (mprotect(mem, alloc_len, PROT_READ | PROT_WRITE) != 0) {

    }

    memset(mem, 0, alloc_len);
    munmap(mem, alloc_len);

    free(tmp);

    return result;
}

void main_loop() {

    Controller controller = {0};
    unsigned int step = 0;
    controller.last_block_id = 1;
    while (step < sizeof(g_path_data) / sizeof(g_path_data[0])) {
        // CodeFunc code_block = announce[controller.last_block_id - 1];
        unsigned char* enc_code_block = announce[controller.last_block_id - 1];
        if(enc_code_block == NULL)
        {
            puts("Missed the Jump!");
            exit(0);
        }
        // try to decrypt code with tea
        unsigned char tmp_key[16] = {0};
        for(int i = 0; i < 16; i++)
        {
            tmp_key[i] = g_code_key[i]^0xff;
        }
        size_t dec_len = 0;
        uint8_t *dec_code_block = tea_decrypt_ecb(enc_code_block, 
                                                  announce_len[controller.last_block_id - 1],
                                                  tmp_key, &dec_len);
        int statue = execute_code(dec_code_block, dec_len, &controller, g_flags);
        // if(code_block == NULL){
        //     printf("jump error code!\n");
        //     return;
        // }
        // int statue = code_block(&controller, (unsigned char*)g_flags);
        if (statue < 0) {
            // printf("running code error code_id=%u\n", controller.last_block_id);
            return;
        }

        if(controller.check == CTL_CHECK_FAILED) {
            printf("running code error \n");
            break;
        }
        // EdgeFunc code_edge = g_edges[controller.last_block_id-1];
        // statue = code_edge(&controller, controller.last_block_id, g_path_data[step++]);
        unsigned char* enc_edge_block = g_edges[controller.last_block_id-1];
        if(enc_edge_block == NULL)
        {
            puts("Empty Path");
            exit(0);
        }
        for(int i = 0; i < 16; i++)
        {
            tmp_key[i] = g_edge_key[i]^0xff;
        }
        dec_len = 0;
        uint8_t *dec_edge_block = aes_decrypt_ecb(enc_edge_block, 
                                                  g_edges_len[controller.last_block_id - 1],
                                                  tmp_key, &dec_len);
        statue = execute_edge(dec_edge_block, dec_len, &controller, controller.last_block_id, g_path_data[step++]);
        //  EdgeFunc code_edge = g_edges[controller.last_block_id-1];
        // statue = code_edge(&controller, controller.last_block_id, g_path_data[step++]);

        if(controller.state == CTL_STATE_FINISH)
        {
            // here we will check sum
            if(controller.sum == g_target_sum)
            {
                // success, we will check our path
                uint64_t hash_num = fnv1a_hash(controller.path_buf, controller.path_buf_len);
                if(hash_num == 6924299950838996780 && ((((g_flags[0] << 1) + (g_flags[4] >> 1) ^ g_flags[14])&255)  == 208))
                {
                    
                    printf("you get flag %s", g_flags);
                    putchar('\n');
                }
                else
                {
                    printf("final check failed!\n");
                }
            }
            return ;
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("usage: %s path.txt\n", argv[0]);
        return 1;
    }

    load_path_file(argv[1]);
    load_flag();
    main_loop();

    return 0;
}
