#include "tea.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

static inline uint32_t be32_to_u32(const uint8_t *b) {
    return ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16) | ((uint32_t)b[2] << 8) | (uint32_t)b[3];
}
static inline void u32_to_be32(uint32_t v, uint8_t *b) {
    b[0] = (v >> 24) & 0xFF;
    b[1] = (v >> 16) & 0xFF;
    b[2] = (v >> 8) & 0xFF;
    b[3] = v & 0xFF;
}

static inline uint32_t u32_wrap(uint32_t x) { return x & 0xFFFFFFFFu; }

static void tea_encrypt_block(uint32_t *v0, uint32_t *v1, const uint32_t k[4], int rounds) {
    uint32_t sum = 0;
    const uint32_t delta = 0x9E3779B9u;
    for (int i = 0; i < rounds; i++) {
        sum = u32_wrap(sum + delta);
        *v0 = u32_wrap(*v0 + (((*v1 << 4) + k[0]) ^ (*v1 + sum) ^ ((*v1 >> 5) + k[1])));
        *v1 = u32_wrap(*v1 + (((*v0 << 4) + k[2]) ^ (*v0 + sum) ^ ((*v0 >> 5) + k[3])));
    }
}

static void tea_decrypt_block(uint32_t *v0, uint32_t *v1, const uint32_t k[4], int rounds) {
    const uint32_t delta = 0x9E3779B9u;
    uint32_t sum = u32_wrap(delta * rounds);
    for (int i = 0; i < rounds; i++) {
        *v1 = u32_wrap(*v1 - (((*v0 << 4) + k[2]) ^ (*v0 + sum) ^ ((*v0 >> 5) + k[3])));
        *v0 = u32_wrap(*v0 - (((*v1 << 4) + k[0]) ^ (*v1 + sum) ^ ((*v1 >> 5) + k[1])));
        sum = u32_wrap(sum - delta);
    }
}

// PKCS7 padding helpers for block_size == 8
static uint8_t* pkcs7_pad(const uint8_t *in, size_t in_len, size_t block_size, size_t *out_len) {
    size_t pad = block_size - (in_len % block_size);
    if (pad == 0) pad = block_size;
    *out_len = in_len + pad;
    uint8_t *out = (uint8_t*)malloc(*out_len);
    if (!out) return NULL;
    memcpy(out, in, in_len);
    memset(out + in_len, (uint8_t)pad, pad);
    return out;
}

static uint8_t* pkcs7_unpad(uint8_t *in_out, size_t in_len, size_t block_size, size_t *out_len) {
    if (in_len == 0 || (in_len % block_size) != 0) return NULL;
    uint8_t pad = in_out[in_len - 1];
    if (pad == 0 || pad > block_size) return NULL;
    for (size_t i = 0; i < pad; i++) {
        if (in_out[in_len - 1 - i] != pad) return NULL;
    }
    *out_len = in_len - pad;
    uint8_t *res = (uint8_t*)malloc(*out_len);
    if (!res) return NULL;
    memcpy(res, in_out, *out_len);
    return res;
}

uint8_t* tea_encrypt_ecb(const uint8_t *plaintext, size_t len, const uint8_t key[TEA_KEY_SIZE], size_t *out_len) {
    if (!plaintext || !key || !out_len) return NULL;
    size_t padded_len;
    uint8_t *padded = pkcs7_pad(plaintext, len, TEA_BLOCK_SIZE, &padded_len);
    if (!padded) return NULL;
    uint8_t *out = (uint8_t*)malloc(padded_len);
    if (!out) { free(padded); return NULL; }

    uint32_t k[4];
    for (int i = 0; i < 4; i++) k[i] = be32_to_u32(key + i*4);

    for (size_t off = 0; off < padded_len; off += TEA_BLOCK_SIZE) {
        uint32_t v0 = be32_to_u32(padded + off);
        uint32_t v1 = be32_to_u32(padded + off + 4);
        tea_encrypt_block(&v0, &v1, k, 32);
        u32_to_be32(v0, out + off);
        u32_to_be32(v1, out + off + 4);
    }

    free(padded);
    *out_len = padded_len;
    return out;
}

uint8_t* tea_decrypt_ecb(const uint8_t *ciphertext, size_t len, const uint8_t key[TEA_KEY_SIZE], size_t *out_len) {
    if (!ciphertext || !key || !out_len) return NULL;
    if ((len % TEA_BLOCK_SIZE) != 0) return NULL;
    uint8_t *buf = (uint8_t*)malloc(len);
    if (!buf) return NULL;
    memcpy(buf, ciphertext, len);

    uint32_t k[4];
    for (int i = 0; i < 4; i++) k[i] = be32_to_u32(key + i*4);

    for (size_t off = 0; off < len; off += TEA_BLOCK_SIZE) {
        uint32_t v0 = be32_to_u32(buf + off);
        uint32_t v1 = be32_to_u32(buf + off + 4);
        tea_decrypt_block(&v0, &v1, k, 32);
        u32_to_be32(v0, buf + off);
        u32_to_be32(v1, buf + off + 4);
    }

    // unpad
    uint8_t *unpadded = pkcs7_unpad(buf, len, TEA_BLOCK_SIZE, out_len);
    free(buf);
    return unpadded;
}
