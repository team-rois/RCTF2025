#ifndef TEA_H
#define TEA_H

#include <stdint.h>
#include <stddef.h>

// TEA block size (bytes)
#define TEA_BLOCK_SIZE 8
// TEA key size (bytes)
#define TEA_KEY_SIZE 16

// Encrypt plaintext (len bytes) with key (16 bytes).
// - Input: plaintext and its length
// - Output: malloc'd ciphertext pointer (must be freed by caller) and out_len set
// Uses PKCS#7 padding to 8-byte blocks.
uint8_t* tea_encrypt_ecb(const uint8_t *plaintext, size_t len, const uint8_t key[TEA_KEY_SIZE], size_t *out_len);

// Decrypt ciphertext (must be multiple of 8) with key.
// - Input: ciphertext and its length (multiple of 8)
// - Output: malloc'd plaintext pointer (must be freed by caller) and out_len set (unpadded length)
uint8_t* tea_decrypt_ecb(const uint8_t *ciphertext, size_t len, const uint8_t key[TEA_KEY_SIZE], size_t *out_len);

#endif // TEA_H
