

This challenge consists of two programs: a Client (Windows) and a Server (Linux).  
Both programs need to be running simultaneously.

- Server: Navigate to the 'server' directory and run ./server.  
- Client: Just double click it .
