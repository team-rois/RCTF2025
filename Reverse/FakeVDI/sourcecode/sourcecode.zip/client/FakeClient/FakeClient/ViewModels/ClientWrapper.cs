﻿using FakeClient.Native;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static FakeClient.Native.LoadEmDLL;

namespace FakeClient.ViewModels
{
    public class TCPClientWrapper : IDisposable
    {
        private IntPtr _dllHandle;
        private IntPtr _clientHandle;

        // 定义委托
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate IntPtr CreateTCPClientDelegate(string host, ushort port, ushort localport);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void DestroyTCPClientDelegate(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int SendDataDelegate(IntPtr handle, byte[] data, UIntPtr size);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int RecvDataDelegate(IntPtr handle, byte[] buffer, UIntPtr bufferSize);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int SendHandShakeReqDelegate(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int RecvHandShakeReqDelegate(IntPtr handle);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate ulong SendLoginDelegate(IntPtr handle,
                                            byte[] username,
                                            byte[] passhash,
                                            uint passhash_len);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int SendOperationAndRecvDelegate(IntPtr handle, ulong session, int seq, int opt, byte[] out_buffer, uint buffer_size);


        private CreateTCPClientDelegate _create;
        private DestroyTCPClientDelegate _destroy;
        private SendDataDelegate _send;
        private RecvDataDelegate _recv;
        private SendHandShakeReqDelegate _sendHandShakeReq;
        private RecvHandShakeReqDelegate _recvHandShakeReq;
        private SendLoginDelegate _loginData;
        private SendOperationAndRecvDelegate _sendOpAndRecv;

        public TCPClientWrapper(string host, ushort port, ushort localport)
        {
            // 1. 加载 DLL
            _dllHandle = LoadEmDLL.LoadEmbeddedDll("FakeClient.Resources.FakeClientComm.dll");

            // 2. 获取函数指针
            _create = LoadEmDLL.GetFunctionDelegate<CreateTCPClientDelegate>(_dllHandle, "CreateTCPClient");
            _destroy = LoadEmDLL.GetFunctionDelegate<DestroyTCPClientDelegate>(_dllHandle, "DestroyTCPClient");
            _send = LoadEmDLL.GetFunctionDelegate<SendDataDelegate>(_dllHandle, "SendData");
            _recv = LoadEmDLL.GetFunctionDelegate<RecvDataDelegate>(_dllHandle, "RecvData");
            _sendHandShakeReq = LoadEmDLL.GetFunctionDelegate<SendHandShakeReqDelegate>(_dllHandle, "SendHandShakeReq");
            _recvHandShakeReq = LoadEmDLL.GetFunctionDelegate<RecvHandShakeReqDelegate>(_dllHandle, "RecvHandShakeReq");
            _loginData = LoadEmDLL.GetFunctionDelegate<SendLoginDelegate>(_dllHandle, "SendLogin");
            _sendOpAndRecv = LoadEmDLL.GetFunctionDelegate<SendOperationAndRecvDelegate>(_dllHandle, "SendOperationAndRecv");

            // 3. 创建 TCPClient 对象
            _clientHandle = _create(host, port, localport);
        }

        public int Send(byte[] data) => _send(_clientHandle, data, (UIntPtr)data.Length);

        public int Receive(byte[] buffer) => _recv(_clientHandle, buffer, (UIntPtr)buffer.Length);

        public int SendHandShake() => _sendHandShakeReq(_clientHandle);

        public int ReceiveHandShake() => _recvHandShakeReq(_clientHandle);

        public ulong Login(string username, byte[] passhash)
        {
            return _loginData(
                _clientHandle,
                System.Text.Encoding.ASCII.GetBytes(username), // 转成 byte[]
                passhash,
                (uint)passhash.Length);
        }

        public int SendOperationAndReceive(ulong session, int seq, int opt, byte[] outBuffer)
        {
            return _sendOpAndRecv(_clientHandle, session, seq, opt, outBuffer, (uint)outBuffer.Length);
        }

        public void Dispose()
        {
            if (_clientHandle != IntPtr.Zero)
            {
                _destroy(_clientHandle);
                _clientHandle = IntPtr.Zero;
            }
        }
    }
}
