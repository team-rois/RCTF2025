﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace FakeClient.Native
{
    public static class LoadEmDLL
    {
        [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr LoadLibrary(string lpFileName);

        [DllImport("kernel32", SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        [DllImport("kernel32", SetLastError = true)]
        private static extern bool FreeLibrary(IntPtr hModule);

        public static IntPtr LoadEmbeddedDll(string resourceName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            // var assembly = Assembly.GetExecutingAssembly();
            using var stream = assembly.GetManifestResourceStream(resourceName);
            if (stream == null)
                throw new Exception($"Resource {resourceName} not found!");

            string tempFile = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid()}.dll");
            using var fs = new FileStream(tempFile, FileMode.Create, FileAccess.ReadWrite, FileShare.Read);
            stream.CopyTo(fs);
            fs.Flush();
            fs.Close();

            var fi = new FileInfo(tempFile);
            Debug.WriteLine($"Wrote {fi.Length} bytes. Attributes: {fi.Attributes}");

            IntPtr handle = LoadLibrary(tempFile);
            if (handle == IntPtr.Zero)
            {
                int err = Marshal.GetLastWin32Error();
                throw new Exception($"Failed to load DLL: {err}");
            }

            // File.Delete(tempFile);
            return handle;
        }

        public static T GetFunctionDelegate<T>(IntPtr dllHandle, string functionName) where T : Delegate
        {
            IntPtr ptr = GetProcAddress(dllHandle, functionName);
            if (ptr == IntPtr.Zero)
                throw new Exception($"Function {functionName} not found in DLL.");
            return Marshal.GetDelegateForFunctionPointer<T>(ptr);
        }
    }
}
