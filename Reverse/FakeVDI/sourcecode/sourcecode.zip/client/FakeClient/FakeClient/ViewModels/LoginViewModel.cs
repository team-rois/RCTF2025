﻿using ReactiveUI;
using System;
using System.ComponentModel;
using System.Reactive;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using DInvoke;                 // NuGet DInvoke
using DynamicInvoke = DInvoke.DynamicInvoke;
using ManualMap = DInvoke.ManualMap;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;

namespace FakeClient.ViewModels;

public class LoginViewModel : ViewModelBase
{
    private string _username = string.Empty;
    private string _password = string.Empty;
    private string _errorMessage = string.Empty;

     private readonly MainWindowViewModel _mainViewModel;

    private bool _showIpPort;
    private int _clickCount;

    private ulong _session;

    public bool ShowIpPort
    {
        get => _showIpPort;
        set => this.RaiseAndSetIfChanged(ref _showIpPort, value);
    }

    public string ServerIp { get; set; } = "127.0.0.1";
    public string ServerPort { get; set; } = "8080";
    public ReactiveCommand<Unit, Unit> SecretClickCommand { get; }

    // public LoginViewModel(MainViewModel mainViewModel)
    public LoginViewModel(MainWindowViewModel mainVm)
    {
        _mainViewModel = mainVm;
        SecretClickCommand = ReactiveCommand.Create(OnSecretClick);
    }

    // public event PropertyChangedEventHandler? PropertyChanged;

    public string Username
    {
        get => _username;
        set
        {
            if (_username != value)
            {
                _username = value;
                // OnPropertyChanged();
                this.RaiseAndSetIfChanged(ref _username, value);
                ((RelayCommand)LoginCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public string Password
    {
        get => _password;
        set
        {
            if (_password != value)
            {
                _password = value;
                // OnPropertyChanged();
                this.RaiseAndSetIfChanged(ref _password, value);
                ((RelayCommand)LoginCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public string ErrorMessage
    {
        get => _errorMessage;
        set
        {
            if (_errorMessage != value)
            {
                // _errorMessage = value;
                // OnPropertyChanged();
                this.RaiseAndSetIfChanged(ref _errorMessage, value);
                // OnPropertyChanged(nameof(HasError));
                this.RaisePropertyChanged(nameof(HasError));
            }
        }
    }

    public bool HasError => !string.IsNullOrEmpty(ErrorMessage);

    private ICommand? _loginCommand;
    public ICommand LoginCommand => _loginCommand ??= new RelayCommand(_ => ExecuteLogin(), _ => CanLogin());

    public static void XorEncrypt(byte[] data, ulong session)
    {
        byte[] key = BitConverter.GetBytes(session);
        int keyLen = key.Length; // 8

        for (int i = 0; i < data.Length; i++)
        {
            data[i] ^= key[i % keyLen];
        }
    }


    private string GetMd5String(string input)
    {
        using var md5 = MD5.Create();
        byte[] bytes = Encoding.UTF8.GetBytes(input);
        byte[] hash = md5.ComputeHash(bytes);
        
        StringBuilder sb = new StringBuilder();
        foreach (byte b in hash)
            sb.Append(b.ToString("x2"));
        return sb.ToString();
    }

    private void ExecuteLogin()
    {
        ErrorMessage = string.Empty;

        try
        {
            var client = new TCPClientWrapper(ServerIp, 
                                                    ushort.Parse(ServerPort), 
                                                    ushort.Parse(Properties.Resources.XPort));

            if (client.SendHandShake() != 1 || client.ReceiveHandShake() != 1)
            {
                ErrorMessage = "Network error!";
                return;
            }

            string md5Pass = GetMd5String(Password);
            byte[] md5Bytes = Encoding.ASCII.GetBytes(md5Pass);

            _session = client.Login(Username, md5Bytes);

            // TODO: show login failed information
            if (_session == ulong.MaxValue)
            {
                ErrorMessage = "Login failed!";
            }
            else
            {
                ErrorMessage = string.Empty;
                XorEncrypt(DrawImage.Data, _session);
            }

            _mainViewModel.ShowMainView(client, _session);
        }
        catch (Exception ex)
        {
            ErrorMessage = $"login failed: {ex.Message}";
        }

        // TODO: update GUI screen
        // _mainViewModel
        
    }

    private bool CanLogin()
    {
        if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Password))
            return false;

        if (!Username.StartsWith("a") || Username.Length != 13)
            return false;

        if (Password.Length != 8)
            return false;

        return true;
    }

    private void OnSecretClick()
    {
        _clickCount++;
        if (_clickCount > 7)
        {
            ShowIpPort = true;
        }
    }
    //protected void OnPropertyChanged([CallerMemberName] string? name = null)
    //{
    //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    //}
}
