﻿using Avalonia.Media.Imaging;
using ReactiveUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FakeClient.ViewModels
{

    public class MainViewModel : INotifyPropertyChanged
    {
        public TCPClientWrapper TCPClient { get; private set; }

        private ulong _session;

        private int seq;

        public ICommand KeyCommand { get; }

        public event PropertyChangedEventHandler? PropertyChanged;

        private Bitmap? _serverImage;
        public Bitmap? ServerImage
        {
            get => _serverImage;
            set
            {
                _serverImage = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ServerImage)));
            }
        }

        private Bitmap? _bottomImage;
        public Bitmap? BottomImage
        {
            get => _bottomImage;
            set
            {
                _bottomImage = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(BottomImage)));
            }
        }

        private byte[] _imageBuffer = new byte[576 * 576 * 3+54];
        public MainViewModel(TCPClientWrapper client,ulong session)
        {
            TCPClient = client;
            _session = session;
            seq = 0;
            KeyCommand = new RelayCommand(ExecuteKeyCommand);
        }

        public static void XorEncrypt(List<byte> data, ulong session)
        {
            byte[] key = BitConverter.GetBytes(session);
            int keyLen = key.Length; // 8
            for (int i = 0; i < data.Count; i++)
            {
                data[i] ^= key[i % keyLen];
            }
        }

        public static byte[] Rc4(byte[] key, byte[] data)
        {
            byte[] s = new byte[256];
            for (int i = 0; i < 256; i++)
                s[i] = (byte)i;

            int j = 0;
            for (int i = 0; i < 256; i++)
            {
                j = (j + s[i] + key[i % key.Length]) & 0xFF;
                (s[i], s[j]) = (s[j], s[i]); // swap
            }

            byte[] output = new byte[data.Length];
            int iIndex = 0, jIndex = 0;

            for (int k = 0; k < data.Length; k++)
            {
                iIndex = (iIndex + 1) & 0xFF;
                jIndex = (jIndex + s[iIndex]) & 0xFF;
                (s[iIndex], s[jIndex]) = (s[jIndex], s[iIndex]);
                byte rnd = s[(s[iIndex] + s[jIndex]) & 0xFF];
                output[k] = (byte)(data[k] ^ rnd);
            }

            return output;
        }

        public void UpdateImage()
        {

            Avalonia.Threading.Dispatcher.UIThread.Post(() =>
            {
                using var ms = new MemoryStream(_imageBuffer);
                ms.Position = 0;
                ServerImage = new Avalonia.Media.Imaging.Bitmap(ms);
            });

        }

        private void WriteBmpToStream(byte[] buffer, int width, int height, Stream stream)
        {
            var wb = new Avalonia.Media.Imaging.WriteableBitmap(
                new Avalonia.PixelSize(width, height),
                new Avalonia.Vector(96, 96),
                Avalonia.Platform.PixelFormat.Bgra8888,
                Avalonia.Platform.AlphaFormat.Premul
            );

            using (var fb = wb.Lock())
            {
                System.Runtime.InteropServices.Marshal.Copy(buffer, 0, fb.Address, buffer.Length);
            }

            wb.Save(stream);
        }

        public static byte[] ComputeMD5(byte[] data)
        {
            using (var md5 = MD5.Create())
            {
                var hashBytes = md5.ComputeHash(data);
                return hashBytes;
            }
        }

        public void TrySaveBmp(byte[] data)
        {
            if (data == null || data.Length < 2)
            {
                return;
            }

            if (data[0] == 0x42 && data[1] == 0x4D)
            {
                try
                {
                    Avalonia.Threading.Dispatcher.UIThread.Post(() =>
                    {
                        using var ms = new MemoryStream(data);
                        ms.Position = 0;
                        BottomImage = new Avalonia.Media.Imaging.Bitmap(ms);
                    });
                }
                catch (Exception ex)
                {
                }
            }
            else
            {
            }
        }

        public static byte[] GenerateBlackBmpBytes(int width, int height)
        {
            
            int bytesPerPixel = 3;
            int stride = ((width * bytesPerPixel + 3) / 4) * 4;
            int pixelDataSize = stride * height;

            byte[] fileHeader = new byte[14];
            fileHeader[0] = 0x42;
            fileHeader[1] = 0x4D;
            int fileSize = 14 + 40 + pixelDataSize;
            BitConverter.GetBytes(fileSize).CopyTo(fileHeader, 2);
            fileHeader[10] = 54;

            byte[] dibHeader = new byte[40];
            BitConverter.GetBytes(40).CopyTo(dibHeader, 0);
            BitConverter.GetBytes(width).CopyTo(dibHeader, 4);
            BitConverter.GetBytes(height).CopyTo(dibHeader, 8);
            BitConverter.GetBytes((short)1).CopyTo(dibHeader, 12);
            BitConverter.GetBytes((short)24).CopyTo(dibHeader, 14);

         
            byte[] pixelData = new byte[pixelDataSize];
            
            byte[] bmpBytes = new byte[fileHeader.Length + dibHeader.Length + pixelData.Length];
            Buffer.BlockCopy(fileHeader, 0, bmpBytes, 0, fileHeader.Length);
            Buffer.BlockCopy(dibHeader, 0, bmpBytes, fileHeader.Length, dibHeader.Length);
            Buffer.BlockCopy(pixelData, 0, bmpBytes, fileHeader.Length + dibHeader.Length, pixelData.Length);

            return bmpBytes;
        }

        private void ExecuteKeyCommand(object? parameter)
        {
            if (parameter is OperationCode op)
            {

                int res = TCPClient.SendOperationAndReceive(_session, seq++, (int)op, _imageBuffer);
                if (res == -1)
                {
                    _imageBuffer = GenerateBlackBmpBytes(576, 576);
                }

                var key = ComputeMD5(_imageBuffer);
                DrawImage.Data = Rc4(key, DrawImage.Data);

                TrySaveBmp(DrawImage.Data);
                UpdateImage();
            }
        }
        public void Close()
        {
            TCPClient?.Dispose();
            TCPClient = null;
        }
    }
}
