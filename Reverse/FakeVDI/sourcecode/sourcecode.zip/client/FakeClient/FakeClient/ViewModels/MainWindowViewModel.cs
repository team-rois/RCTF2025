﻿using System.ComponentModel;
using FakeClient.Views;

namespace FakeClient.ViewModels;

public class MainWindowViewModel : INotifyPropertyChanged
{
    private object _currentView;

    public object CurrentView
    {
        get => _currentView;
        set
        {
            _currentView = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentView)));
        }
    }
    public TCPClientWrapper TCPClient { get; private set; }

    public void SetTCPClient(TCPClientWrapper client)
    {
        TCPClient = client;
    }

    public MainWindowViewModel()
    {
        // 默认显示 LoginView
        CurrentView = new LoginViewModel(this);
    }

    public void ShowMainView(TCPClientWrapper client, ulong _session)
    {
        CurrentView = new MainViewModel(client, _session);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
}
