﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FakeClient.ViewModels
{
    public enum OperationCode
    {
        OP_UP = 0x1,
        OP_DOWN = 0x2,
        OP_LEFT = 0x3,
        OP_RIGHT = 0x4,
        OP_ENTER = 0x5
    }
}
