﻿using ReactiveUI;

namespace FakeClient.ViewModels;

public class ViewModelBase : ReactiveObject
{
}
