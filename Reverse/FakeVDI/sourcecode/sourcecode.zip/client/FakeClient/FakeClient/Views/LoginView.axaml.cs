﻿using Avalonia.Controls;
using Avalonia.Input;
using FakeClient.ViewModels;
using System;
using FakeClient.ViewModels;

namespace FakeClient.Views;

public partial class LoginView : UserControl
{
    public LoginView()
    {
        InitializeComponent();
    }
}
