﻿using Avalonia.Controls;
using Avalonia.Input;
using System.Diagnostics;
using FakeClient.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Avalonia.Threading;

namespace FakeClient.Views
{
    public partial class MainView : UserControl
    {
        private MainViewModel? _viewModel;
        public MainView()
        {
            InitializeComponent();
            //DataContext = new MainViewModel();
            this.Focusable = true;
            _viewModel = this.DataContext as MainViewModel;
            this.AttachedToVisualTree += (_, _) =>
            {

                FocusGrabber.Focus();
                _viewModel = this.DataContext as MainViewModel;
            };
            // this.AttachedToVisualTree += (s, e) => this.Focus();
        }
        private OperationCode? MapKeyToOp(Key key)
        {
            return key switch
            {
                Key.Up => OperationCode.OP_UP,
                Key.Down => OperationCode.OP_DOWN,
                Key.Left => OperationCode.OP_LEFT,
                Key.Right => OperationCode.OP_RIGHT,
                Key.Enter => OperationCode.OP_ENTER,
                _ => null
            };
        }
        private void UserControl_KeyDown(object? sender, KeyEventArgs e)
        {
            if (DataContext is MainViewModel vm)
            {
                var op = MapKeyToOp(e.Key);
                if (op.HasValue)
                {
                    if (vm.KeyCommand?.CanExecute(op.Value) ?? false)
                        vm.KeyCommand.Execute(op.Value);

                    e.Handled = true;
                }
            }

        }
    }
}
