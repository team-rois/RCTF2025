﻿using Avalonia.Controls;
using FakeClient.ViewModels;

namespace FakeClient.Views;

public partial class MainWindow : Window
{

    public MainWindow()
    {
        InitializeComponent();
    }
}
