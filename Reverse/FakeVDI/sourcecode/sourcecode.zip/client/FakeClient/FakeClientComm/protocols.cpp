#include "protocols.h"
// (no extra implementation needed �� most methods inline in header)
// But we provide helper function to extract strings and bytes from parsed structures

#include <string>
#include <algorithm>

std::string username_from_login_req(const LoginReqPacket& p) {
    // username is null-padded
    size_t n = 0;
    while (n < 32 && p.username[n] != 0) ++n;
    return std::string((const char*)p.username, n);
}

std::vector<uint8_t> password_hash_from_login_req(const LoginReqPacket& p) {
    return std::vector<uint8_t>(p.password_hash, p.password_hash + 32);
}

// For login ack: read status and session id in host order
uint8_t login_ack_status(const LoginAckPacket& p) {
    return p.status;
}
uint64_t login_ack_session(const LoginAckPacket& p) {
    return p.session_id;
}

// For operation/feedback: convert fields to host order when reading
uint64_t feedback_session(const FeedbackAckPacket& p) {
    return ntohll(p.session_id);
}
uint32_t feedback_sequence(const FeedbackAckPacket& p) {
    return ntohl(p.sequence);
}
uint32_t feedback_checksum(const FeedbackAckPacket& p) {
    return ntohl(p.image_checksum);
}


// Helper: htonll / ntohll (not standard)
//static inline uint64_t htonll(uint64_t x) {
//#if defined(__BYTE_ORDER) && __BYTE_ORDER == __LITTLE_ENDIAN || defined(_WIN32)
//    uint64_t hi = htonl((uint32_t)(x >> 32));
//    uint64_t lo = htonl((uint32_t)(x & 0xffffffffULL));
//    return (lo << 32) | hi;
//#else
//    return x;
//#endif
//}
//static inline uint64_t ntohll(uint64_t x) {
//#if defined(__BYTE_ORDER) && __BYTE_ORDER == __LITTLE_ENDIAN || defined(_WIN32)
//    uint64_t hi = ntohl((uint32_t)(x >> 32));
//    uint64_t lo = ntohl((uint32_t)(x & 0xffffffffULL));
//    return (lo << 32) | hi;
//#else
//    return x;
//#endif
//}
