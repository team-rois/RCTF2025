#pragma once
#pragma once
#include <cstdint>
#include <vector>
#include <string>
#include <cstring>
#include <stdexcept>
#include <optional>

#if defined(_WIN32)
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <arpa/inet.h> // htonl/htons etc
#endif

// Helper: htonll / ntohll (not standard)
//static inline uint64_t htonll(uint64_t x);
//static inline uint64_t ntohll(uint64_t x);

#pragma pack(push, 1)
struct PacketHeader {
    uint32_t magic;
    uint32_t length; // body length (big-endian in wire)
    uint8_t msg_type;
    uint8_t reserved;
};
#pragma pack(pop)

enum MessageType : uint8_t {
    HandshakeReqType = 0x01,
    HandshakeAckType = 0x02,
    LoginReqType = 0x11,
    LoginAckType = 0x12,
    OperationReqType = 0x21,
    FeedbackAckType = 0x22,
};

enum OperateType : uint8_t {
    OP_UP = 0x1,
    OP_DOWN = 0x2,
    OP_LEFT = 0x3,
    OP_RIGHT = 0x4,
    OP_ENTER = 0x5,
};

// LoginReqPacket (header + username[32] + password_hash[32])
#undef min
#pragma pack(push,1)
struct LoginReqPacket {
    PacketHeader header;
    uint8_t username[32];
    uint8_t password_hash[32];

    // build from std::string inputs (username shorter than 32)
    static LoginReqPacket make(const std::string& username, const std::vector<uint8_t>& password_hash_bytes, uint32_t magic = 0xDEADBEEF /* 'VDI\\0' as example */) {
        if (password_hash_bytes.size() != 32) throw std::runtime_error("password_hash must be 32 bytes");
        LoginReqPacket p;
        p.header.magic = htonl(magic);
        p.header.length = htonl((uint32_t)(32 + 32));
        p.header.msg_type = LoginReqType;
        p.header.reserved = 0;
        memset(p.username, 0, sizeof(p.username));
        memset(p.password_hash, 0, sizeof(p.password_hash));
        // copy username (truncated if longer)
        size_t copy_len = std::min(username.size(), sizeof(p.username));
        memcpy(p.username, username.data(), copy_len);
        memcpy(p.password_hash, password_hash_bytes.data(), 32);
        return p;
    }

    std::vector<uint8_t> serialize() const {
        std::vector<uint8_t> out;
        out.reserve(sizeof(PacketHeader) + 32 + 32);
        // header fields already stored in network order in make(); but ensure conversion
        out.insert(out.end(), (const uint8_t*)&header, (const uint8_t*)&header + sizeof(header));
        out.insert(out.end(), username, username + 32);
        out.insert(out.end(), password_hash, password_hash + 32);
        return out;
    }

    // parse from buffer; expects full header+body present
    static LoginReqPacket parse(const uint8_t* buf, size_t len) {
        if (len < sizeof(PacketHeader) + 64) throw std::runtime_error("buffer too small for LoginReqPacket");
        LoginReqPacket p;
        memcpy(&p.header, buf, sizeof(PacketHeader));
        memcpy(p.username, buf + sizeof(PacketHeader), 32);
        memcpy(p.password_hash, buf + sizeof(PacketHeader) + 32, 32);
        // header fields kept in network order; user must ntohl/ntohs when using if needed
        return p;
    }
};
#pragma pack(pop)

// LoginAckPacket (header + status + session_id)
#pragma pack(push,1)
struct LoginAckPacket {
    PacketHeader header;
    uint8_t status;
    uint64_t session_id;

    static LoginAckPacket make(uint8_t status, uint64_t session_id, uint32_t magic = 0xDEADBEEF) {
        LoginAckPacket p;
        p.header.magic = htonl(magic);
        p.header.length = htonl((uint32_t)(1 + 8));
        p.header.msg_type = LoginAckType;
        p.header.reserved = 0;
        p.status = status;
        p.session_id = htonll(session_id);
        return p;
    }

    std::vector<uint8_t> serialize() const {
        std::vector<uint8_t> out;
        out.reserve(sizeof(PacketHeader) + 1 + 8);
        out.insert(out.end(), (const uint8_t*)&header, (const uint8_t*)&header + sizeof(header));
        out.push_back(status);
        uint64_t net_sid = session_id;
        const uint8_t* p = (const uint8_t*)&net_sid;
        out.insert(out.end(), p, p + 8);
        return out;
    }

    static LoginAckPacket parse(const uint8_t* buf, size_t len) {
        if (len < sizeof(LoginAckPacket)) throw std::runtime_error("buffer too small for LoginAckPacket");
        LoginAckPacket p;
        memcpy(&p.header, buf, sizeof(PacketHeader));
        p.status = buf[sizeof(PacketHeader)];
        uint64_t sid;
        memcpy(&sid, buf + sizeof(PacketHeader) + 1, 8);
        p.session_id = ntohll(sid); // still network-order; use ntohll when reading
        return p;
    }
};
#pragma pack(pop)

#pragma pack(push,1)
struct OperationReqPacket {
    PacketHeader header;
    uint64_t session_id;
    uint32_t sequence;
    uint8_t operation_code;

    static OperationReqPacket make(uint64_t session_id, uint32_t sequence, uint8_t op, uint32_t magic = 0xDEADBEEF) {
        OperationReqPacket p;
        p.header.magic = htonl(magic);
        p.header.length = htonl((uint32_t)(8 + 4 + 1));
        p.header.msg_type = OperationReqType;
        p.header.reserved = 0;
        p.session_id = htonll(session_id);
        p.sequence = htonl(sequence);
        p.operation_code = op;
        return p;
    }

    std::vector<uint8_t> serialize() const {
        std::vector<uint8_t> out;
        out.reserve(sizeof(PacketHeader) + 8 + 4 + 1);
        out.insert(out.end(), (const uint8_t*)&header, (const uint8_t*)&header + sizeof(header));
        const uint8_t* psid = (const uint8_t*)&session_id;
        out.insert(out.end(), psid, psid + 8);
        const uint8_t* pseq = (const uint8_t*)&sequence;
        out.insert(out.end(), pseq, pseq + 4);
        out.push_back(operation_code);
        return out;
    }

    static OperationReqPacket parse(const uint8_t* buf, size_t len) {
        if (len < sizeof(PacketHeader) + (8 + 4 + 1)) throw std::runtime_error("buffer too small for OperationReqPacket");
        OperationReqPacket p;
        memcpy(&p.header, buf, sizeof(PacketHeader));
        memcpy(&p.session_id, buf + sizeof(PacketHeader), 8);
        memcpy(&p.sequence, buf + sizeof(PacketHeader) + 8, 4);
        p.operation_code = buf[sizeof(PacketHeader) + 8 + 4];
        return p;
    }
};
#pragma pack(pop)

#pragma pack(push,1)
struct FeedbackAckPacket {
    PacketHeader header;
    uint64_t session_id;
    uint32_t sequence;
    uint32_t image_checksum;

    static FeedbackAckPacket parse(const uint8_t* buf, size_t len) {
        if (len < sizeof(PacketHeader) + 8 + 4 + 4) throw std::runtime_error("buffer too small for FeedbackAckPacket");
        FeedbackAckPacket p;
        memcpy(&p.header, buf, sizeof(PacketHeader));
        memcpy(&p.session_id, buf + sizeof(PacketHeader), 8);
        memcpy(&p.sequence, buf + sizeof(PacketHeader) + 8, 4);
        memcpy(&p.image_checksum, buf + sizeof(PacketHeader) + 8 + 4, 4);
        return p;
    }

    std::vector<uint8_t> serialize() const {
        std::vector<uint8_t> out;
        out.reserve(sizeof(PacketHeader) + 8 + 4 + 4);
        out.insert(out.end(), (const uint8_t*)&header, (const uint8_t*)&header + sizeof(header));
        const uint8_t* psid = (const uint8_t*)&session_id;
        out.insert(out.end(), psid, psid + 8);
        const uint8_t* pseq = (const uint8_t*)&sequence;
        out.insert(out.end(), pseq, pseq + 4);
        const uint8_t* pchk = (const uint8_t*)&image_checksum;
        out.insert(out.end(), pchk, pchk + 4);
        return out;
    }
};
#pragma pack(pop)

// Utility: convert network header to host-friendly header (returns host-order)
static inline PacketHeader header_network_to_host(const PacketHeader& netHeader) {
    PacketHeader h = netHeader;
    h.magic = ntohl(netHeader.magic);
    h.length = ntohl(netHeader.length);
    // msg_type and reserved are 1-byte values
    return h;
}

std::string username_from_login_req(const LoginReqPacket& p);
std::vector<uint8_t> password_hash_from_login_req(const LoginReqPacket& p);
uint8_t login_ack_status(const LoginAckPacket& p);
uint64_t login_ack_session(const LoginAckPacket& p);
uint64_t feedback_session(const FeedbackAckPacket& p);
uint32_t feedback_sequence(const FeedbackAckPacket& p);
uint32_t feedback_checksum(const FeedbackAckPacket& p);