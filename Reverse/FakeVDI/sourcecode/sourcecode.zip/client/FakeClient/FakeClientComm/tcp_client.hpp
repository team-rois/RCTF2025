// windows_tcp_client.cpp
#include "protocols.h"
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <vector>
#include <string>

#pragma comment(lib, "ws2_32.lib")

class TCPClient {
private:
    SOCKET sockfd;
public:
    TCPClient() : sockfd(INVALID_SOCKET) {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
            std::cerr << "WSAStartup failed\n";
        }
    }

    ~TCPClient() {
        close_socket();
        WSACleanup();
    }

    bool connect_to(const std::string& host, uint16_t port, uint16_t local_port = 0) {
        close_socket();
        struct addrinfo hints {};
        struct addrinfo* res = nullptr;
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;
        std::string sport = std::to_string(port);

        int rv = getaddrinfo(host.c_str(), sport.c_str(), &hints, &res);
        if (rv != 0) {
            std::cerr << "getaddrinfo error: " << rv << "\n";
            return false;
        }

        for (struct addrinfo* p = res; p != nullptr; p = p->ai_next) {
            SOCKET s = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
            if (s == INVALID_SOCKET) continue;
            if (local_port != 0) {
                sockaddr_in localAddr{};
                localAddr.sin_family = AF_INET;
                localAddr.sin_addr.s_addr = htonl(INADDR_ANY); // ������������
                localAddr.sin_port = htons(local_port);

                if (bind(s, (sockaddr*)&localAddr, sizeof(localAddr)) == SOCKET_ERROR) {
                    closesocket(s);
                    continue; // ��ʧ�ܣ�����һ��
                }
            }
            if (connect(s, p->ai_addr, (int)p->ai_addrlen) == 0) {
                sockfd = s;
                break;
            }
            closesocket(s);
        }

        freeaddrinfo(res);
        return sockfd != INVALID_SOCKET;
    }

    void close_socket() {
        if (sockfd != INVALID_SOCKET) {
            closesocket(sockfd);
            sockfd = INVALID_SOCKET;
        }
    }

    bool send_all(const uint8_t* data, size_t len) {
        size_t sent = 0;
        while (sent < len) {
            int n = ::send(sockfd, reinterpret_cast<const char*>(data + sent), (int)(len - sent), 0);
            if (n == SOCKET_ERROR) return false;
            if (n == 0) return false;
            sent += (size_t)n;
        }
        return true;
    }

    bool recv_all(uint8_t* buf, size_t n) {
        size_t recvd = 0;
        while (recvd < n) {
            int r = ::recv(sockfd, reinterpret_cast<char*>(buf + recvd), (int)(n - recvd), 0);
            if (r == SOCKET_ERROR || r == 0) return false;
            recvd += (size_t)r;
        }
        return true;
    }

    bool send_handshake_req() {
        auto magic = 0xDEADBEEF;
        PacketHeader header;
        header.magic = htonl(magic);
        header.length = 0;
        header.msg_type = HandshakeReqType;
        header.reserved = 0;

        std::vector<uint8_t> out;
        out.reserve(sizeof(PacketHeader));
        // header fields already stored in network order in make(); but ensure conversion
        out.insert(out.end(), (const uint8_t*)&header, (const uint8_t*)&header + sizeof(header));
        return send_all(out.data(), out.size());
    }
    bool send_login(const std::string& username, const std::vector<uint8_t>& pass_hash) {
        auto pkt = LoginReqPacket::make(username, pass_hash);
        auto bytes = pkt.serialize();
        return send_all(bytes.data(), bytes.size());
    }

    bool recv_handshake_ack() {
        PacketHeader ackHeader;
        if (!recv_all(reinterpret_cast<uint8_t*>(&ackHeader), sizeof(PacketHeader))) return false;
        return ackHeader.magic == htonl(0xDEADBEEF) && ackHeader.msg_type == HandshakeAckType;
    }
    std::optional<std::pair<PacketHeader, std::vector<uint8_t>>> recv_next_packet() {
        PacketHeader netHeader;
        if (!recv_all(reinterpret_cast<uint8_t*>(&netHeader), sizeof(PacketHeader))) return std::nullopt;
        PacketHeader hostHeader = header_network_to_host(netHeader);
        uint32_t body_len = hostHeader.length;
        std::vector<uint8_t> body(body_len);
        if (body_len > 0) {
            if (!recv_all(body.data(), body_len)) return std::nullopt;
        }
        return std::make_pair(netHeader, std::move(body));
    }

    static LoginAckPacket parse_login_ack(const PacketHeader& netHeader, const std::vector<uint8_t>& body) {
        std::vector<uint8_t> full;
        full.reserve(sizeof(PacketHeader) + body.size());
        full.insert(full.end(), (const uint8_t*)&netHeader, (const uint8_t*)&netHeader + sizeof(PacketHeader));
        full.insert(full.end(), body.begin(), body.end());
        return LoginAckPacket::parse(full.data(), full.size());
    }

    static std::pair<FeedbackAckPacket, std::vector<uint8_t>> parse_feedback_with_image(const PacketHeader& netHeader, const std::vector<uint8_t>& body) {
        if (body.size() < (8 + 4 + 4)) throw std::runtime_error("feedback body too small");
        std::vector<uint8_t> full;
        full.reserve(sizeof(PacketHeader) + body.size());
        full.insert(full.end(), (const uint8_t*)&netHeader, (const uint8_t*)&netHeader + sizeof(PacketHeader));
        full.insert(full.end(), body.begin(), body.end());
        FeedbackAckPacket ack = FeedbackAckPacket::parse(full.data(), full.size());
        size_t fixed_sz = 8 + 4 + 4;
        std::vector<uint8_t> img;
        if (body.size() > fixed_sz) {
            img.insert(img.end(), body.begin() + fixed_sz, body.end());
        }
        return { ack, img };
    }
};
