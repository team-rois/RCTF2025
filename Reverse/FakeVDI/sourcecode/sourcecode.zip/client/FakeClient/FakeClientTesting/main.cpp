#include "../FakeClientComm/protocols.h"
#include "../FakeClientComm/tcp_client.hpp"
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include "../FakeClientComm/md5.h"
#include "../FakeClientComm/enc_data.h"

// ��ȡ�ļ�
std::vector<unsigned char> readFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    return std::vector<unsigned char>((std::istreambuf_iterator<char>(file)), {});
}

std::vector<unsigned char> md5_bytes(const std::vector<unsigned char>& my_data) {
    printf("md5 size :%d\n", my_data.size());
    MD5Context md5;
    md5Init(&md5);
    md5Update(&md5, (uint8_t*)my_data.data(), my_data.size());

    unsigned char digest[16];
    md5Finalize(&md5);
    return std::vector<unsigned char>(md5.digest, &md5.digest[16]);
}

// encrypt with session id
void xor_encrypt(std::vector<uint8_t>& data, uint64_t session) {
    uint8_t* key = reinterpret_cast<uint8_t*>(&session);
    size_t key_len = sizeof(session); // 8
    for (size_t i = 0; i < data.size(); i++) {
        data[i] ^= key[i % key_len];
    }
}

// RC4 ʵ��
std::vector<unsigned char> rc4(const std::vector<unsigned char>& key, const std::vector<unsigned char>& data) {
    std::vector<unsigned char> s(256);
    for (int i = 0; i < 256; i++) s[i] = i;

    int j = 0;
    for (int i = 0; i < 256; i++) {
        j = (j + s[i] + key[i % key.size()]) & 0xFF;
        std::swap(s[i], s[j]);
    }

    std::vector<unsigned char> out(data.size());
    int i = 0; j = 0;
    for (size_t k = 0; k < data.size(); k++) {
        i = (i + 1) & 0xFF;
        j = (j + s[i]) & 0xFF;
        std::swap(s[i], s[j]);
        unsigned char rnd = s[(s[i] + s[j]) & 0xFF];
        out[k] = data[k] ^ rnd;
    }
    return out;
}

//enum MOVE {
//    OP_UP = 1,
//    OP_DOWN = 2,
//    OP_LEFT = 3,
//    OP_RIGHT = 4,
//    OP_ENTER = 5
//};
unsigned char steps[] = {
    OP_RIGHT,
    OP_LEFT,
    OP_LEFT,
    OP_RIGHT,
    OP_UP,
    OP_RIGHT,
    OP_RIGHT,
    OP_UP,
    OP_UP,
    OP_RIGHT,
    OP_DOWN,
    OP_LEFT,
};

// Opaque handle (forward declaration)
struct TCPClientHandle { TCPClient* ptr; };

extern "C" __declspec(dllexport) TCPClientHandle* CreateTCPClient(const char* host, uint16_t port, uint16_t localport) {
    TCPClientHandle* handle = new TCPClientHandle;
    handle->ptr = new TCPClient();
    handle->ptr->connect_to(host, port, localport);
    return handle;
}

extern "C" __declspec(dllexport) void DestroyTCPClient(TCPClientHandle* handle) {
    if (handle) {
        delete handle->ptr;
        delete handle;
    }
}

extern "C" __declspec(dllexport) int SendData(TCPClientHandle* handle, const uint8_t* data, size_t size) {
    if (!handle || !handle->ptr) return -1;
    return handle->ptr->send_all(data, size);  // ������ TCPClient ���������
}

extern "C" __declspec(dllexport) int RecvData(TCPClientHandle* handle, uint8_t* buffer, size_t bufferSize) {
    if (!handle || !handle->ptr) return -1;
    auto rsp = handle->ptr->recv_next_packet();
    if (!rsp) return 0;
    auto body = rsp->second;
    if (body.size() > bufferSize) return -2; // ����������
    memcpy(buffer, body.data(), body.size());
    return (int)body.size();
}


extern "C" __declspec(dllexport) int SendHandShakeReq(TCPClientHandle* handle) {
    if (!handle || !handle->ptr) return -1;
    return handle->ptr->send_handshake_req();
}

extern "C" __declspec(dllexport) int RecvHandShakeReq(TCPClientHandle* handle) {
    if (!handle || !handle->ptr) return -1;
    return handle->ptr->recv_handshake_ack();
}



extern "C" __declspec(dllexport) UINT64 SendLogin(TCPClientHandle* handle, char* username,
    const uint8_t* passhash,
    size_t passhash_len) {
    if (!handle || !handle->ptr) return -1;

    std::vector<uint8_t> pass(passhash, passhash + passhash_len);

    if (!handle->ptr->send_login(username, pass)) {
        std::cerr << "send login failed\n";
        return -1;
    }
    auto pk = handle->ptr->recv_next_packet();
    if (!pk) {
        std::cerr << "recv ack failed\n";
        return -1;
    }
    PacketHeader netHeader = pk->first;
    auto body = pk->second;
    auto hostHeader = header_network_to_host(netHeader);
    if (hostHeader.msg_type != LoginAckType) {
        std::cerr << "unexpected msg type: " << (int)hostHeader.msg_type << "\n";
        return -1;
    }
    LoginAckPacket ack = TCPClient::parse_login_ack(netHeader, body);
    uint8_t status = login_ack_status(ack);
    uint64_t session = login_ack_session(ack);
    // std::cout << "login status=" << (int)status << " session=" << session << "\n";
    return session;
}

extern "C" __declspec(dllexport) int SendOperationAndRecv(
    TCPClientHandle* handle,
    unsigned long long session, int seq, int opt,
    uint8_t* out_buffer, size_t buffer_size) {
    if (!handle || !handle->ptr) return -1;
    auto op = OperationReqPacket::make(session, seq, opt);
    auto op_bytes = op.serialize();
    handle->ptr->send_all(op_bytes.data(), op_bytes.size());

    auto rsp = handle->ptr->recv_next_packet();
    if (!rsp) { std::cerr << "no feedback\n"; return -1; }
    auto netHdr2 = rsp->first;
    auto body2 = rsp->second;
    auto hostHdr2 = header_network_to_host(netHdr2);
    if (hostHdr2.msg_type == FeedbackAckType) {
        auto [fb, img] = TCPClient::parse_feedback_with_image(netHdr2, body2);
        if (buffer_size < img.size()) return -1;
        // check if it's valid image
        if (img.size() < 7) return -1;
        memcpy(out_buffer, img.data(), img.size());
        return img.size();
    }
    else {
        std::cerr << "unexpected msg type after op\n";
        return -1;
    }
}


int main(int argc, char** argv) {
    std::string host = "127.0.0.1";
    uint16_t port = 23333; // README ָ��������� 23333
    TCPClient client;
    if (!client.connect_to(host, port, 33332)) {
        std::cerr << "connect failed\n";
        return 1;
    }

    // first we should send req packet
    // 
    if (!client.send_handshake_req())
    {
        std::cerr << "send handshake error" << std::endl;
        return 1;
    }

    // here we should recv the handshake data
    
    if (!client.recv_handshake_ack())
    {
        std::cerr << "recv handshake error" << std::endl;
        return 1;
    }
    std::string username = "adm1niStrat0r"; // example
    std::vector<uint8_t> passhash = { 0x33,0x64,0x65,0x61,0x63,0x38,0x31,0x61,0x65,0x39,0x34,0x36,0x30,0x33,0x62,0x66,0x31,0x38,0x61,0x62,0x31,0x62,0x37,0x30,0x66,0x34,0x38,0x66,0x61,0x37,0x37,0x66 };
    // passhash.

    if (!client.send_login(username, passhash)) {
        std::cerr << "send login failed\n";
        return 1;
    }

    auto pk = client.recv_next_packet();
    if (!pk) {
        std::cerr << "recv ack failed\n";
        return 1;
    }
    PacketHeader netHeader = pk->first;
    auto body = pk->second;
    auto hostHeader = header_network_to_host(netHeader);
    if (hostHeader.msg_type != LoginAckType) {
        std::cerr << "unexpected msg type: " << (int)hostHeader.msg_type << "\n";
        return 1;
    }
    LoginAckPacket ack = TCPClient::parse_login_ack(netHeader, body);
    uint8_t status = login_ack_status(ack);
    uint64_t session = login_ack_session(ack);
    std::cout << "login status=" << (int)status << " session=" << session << "\n";
    if (status != 0) return 1;

    auto op = OperationReqPacket::make(session, 0, OP_ENTER);
    auto op_bytes = op.serialize();
    client.send_all(op_bytes.data(), op_bytes.size());

    auto rsp = client.recv_next_packet();
    if (!rsp) { std::cerr << "no feedback\n"; return 1; }
    auto netHdr2 = rsp->first;
    auto body2 = rsp->second;
    auto hostHdr2 = header_network_to_host(netHdr2);

    std::vector<std::vector<uint8_t>> all_images;

    if (hostHdr2.msg_type == FeedbackAckType) {
        auto [fb, img] = TCPClient::parse_feedback_with_image(netHdr2, body2);
        std::cout << "Got feedback seq=" << feedback_sequence(fb) << " checksum=" << feedback_checksum(fb)
            << " image bytes=" << img.size() << "\n";
        all_images.push_back(std::move(img));
    }
    else {
        std::cerr << "unexpected msg type after op\n";
    }

    int seq = 1;

    for (auto each_step : steps)
    {
        auto op = OperationReqPacket::make(session, seq++, each_step);
        auto op_bytes = op.serialize();
        client.send_all(op_bytes.data(), op_bytes.size());

        // ���շ�������ͼƬ��
        auto rsp = client.recv_next_packet();
        if (!rsp) { std::cerr << "no feedback\n"; return 1; }
        auto netHdr2 = rsp->first;
        auto body2 = rsp->second;
        auto hostHdr2 = header_network_to_host(netHdr2);
        if (hostHdr2.msg_type == FeedbackAckType) {
            auto [fb, img] = TCPClient::parse_feedback_with_image(netHdr2, body2);
            std::cout << "Got feedback seq=" << feedback_sequence(fb) << " checksum=" << feedback_checksum(fb)
                << " image bytes=" << img.size() << "\n";
            all_images.push_back(std::move(img));
        }
        else {
            std::cerr << "unexpected msg type after op\n";
        }
    }

    std::vector<uint8_t> encdata(enc_data, enc_data + sizeof(enc_data));
    for (int i = (int)all_images.size() - 1; i >= 0; --i) {

        // here we get images
        auto img = all_images[i];
        // then we encrypt all data
        auto key = md5_bytes(img);
        encdata = rc4(key, encdata);
    }

    // we try to dump this encdata into file
    std::ofstream ofs1("encdata.stage1", std::ios::binary);
    if (!ofs1) {
        std::cerr << "Could not open encdata.stage1\n";
        return 1;
    }    
    ofs1.write(reinterpret_cast<const char*>(encdata.data()), encdata.size());
    ofs1.close();


    xor_encrypt(encdata, session);

    std::ofstream ofs2("encdata.stage2", std::ios::binary);
    if (!ofs2) {
        std::cerr << "Could not open encdata.stage1\n";
        return 1;
    }
    ofs2.write(reinterpret_cast<const char*>(encdata.data()), encdata.size());
    ofs2.close();

    printf("before xor decrypt first ten data:\n");
    for (int i = 0; i < 10; i++)
    {
        printf("0x%02x,", encdata[i]);
    }
    puts("");
    // here we will decrypt it to make sure it can be resolve
    xor_encrypt(encdata, session);
    uint8_t* key_ = reinterpret_cast<uint8_t*>(&session);
    size_t key_len = sizeof(session);
    printf("xor decrypt key:\n");
    for (int i =0;i < key_len; i++)
    {
        printf("0x%02x,", key_[i]);
    }
    puts("");
    printf("first xor decrypt first ten data:\n");
    for (int i = 0; i < 10; i++)
    {
        printf("0x%02x,", encdata[i]);
    }
    puts("");



    // here we will decrypt data
    std::vector<uint8_t> fin_data(encdata);
    for (int i = 0; i < all_images.size(); i++)
    {
        auto img = all_images[i];
        // then we encrypt all data
        auto key = md5_bytes(img);
        printf("now the key is:");
        for (auto each : key)
        {
            printf("0x%02x,", each);

        }
        puts("enc[:10]:");
        for (int i = 0; i < 10; i++)
        {
            printf("0x%02x,", fin_data[i]);
        }
        puts("");
        fin_data = rc4(key, fin_data);
    }

    // now we will check if encdata can be decrypted
    std::ofstream ofs("output.bmp", std::ios::binary);
    if (!ofs) {
        std::cerr << "�޷����ļ�д��\n";
        return 1;
    }

    // д������ vector
    ofs.write(reinterpret_cast<const char*>(fin_data.data()), fin_data.size());

    ofs.close();
    std::cout << "д����ɣ���д�� " << fin_data.size() << " �ֽ�\n";

    return 0;
}
