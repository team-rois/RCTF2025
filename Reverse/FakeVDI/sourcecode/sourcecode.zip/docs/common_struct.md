## 传输数据

传输数据支持如下类型

类型|定义数据|长度(字节数，描述value中的长度)
------|------|------
u8    |   0  |  1
u16   |   1  |  2
u32   |   2  |  4
u64   |   3  |  8
raw   |   4  |  length 描述长度


使用TLV的形式进行定义:
```
 - tag: 类型（属性类型，1字节）
 - length: 长度（除去当前数据长度后的数据，2字节）
 - value：具体数据
```



## 数据包类型


### 数据包通用头部

```
Packet:
  header: u32   # 魔数，固定为 0xDEADBEEF，用于快速识别数据包。
  length: u16   # 包体长度。不包含通用包头自身的 8 字节。
  type:   u8    # 消息类型代码。见下文“MessageType”章节。
  reserved: u8  # 保留字段，当前必须为 0x00。
```

### MessageType

数据类型如下

类型代码|宏定义|方向|描述
-------|-----|---|-----
0x01|MSG_HANDSHAKE_REQ|C -> S|握手请求
0x02|MSG_HANDSHAKE_ACK|S -> C|握手确认
0x11|MSG_LOGIN_REQ|C -> S|登录请求
0x12|MSG_LOGIN_ACK|S -> C|登录确认
0x21|MSG_OPERATION_REQ|C -> S|操作请求
0x22|MSG_FEEDBACK_ACK|S -> C|操作反馈
			

### 握手数据包 MSG_HANDSHAKE_REQ

发起请求的时候需要先发起这个，相当于ping

方向: Client -> Server

描述: 客户端发起的第一个包，用于确认服务器是否在线。

包体: 无包体，length 字段为 0。

### 确认数据包 MSG_HANDSHAKE_ACK

方向: Server -> Client

描述: 服务器对握手请求的响应。

包体: 无包体，length 字段为 0。

### 登录数据包 MSG_LOGIN_REQ

方向: Client -> Server

描述: 客户端发送用户名和密码的哈希进行登录。

包体结构:

字段名|数据类型|长度 (字节)|描述
----|---------|---------|--
username|char[32]|32|用户名，UTF-8 编码，以 \0 结尾。
password_hash|char[32]|32|密码哈希。注意: 这是一个自定义哈希算法，hash(password + "salt_string")，需要逆向分析得出。

### 登录确认 MSG_LOGIN_ACK

方向: Server -> Client

描述: 服务器验证登录信息后，返回会话 ID。

包体结构:
字段名|数据类型|长度 (字节)|描述
------|--------|----------|-----
status|uint8_t|1|登录状态。0x00 表示成功, 0x01 表示失败。
session_id|uint64_t|8|会话 ID。仅在 status 为 0x00 时有效。注意: 该 ID 由 (timestamp << 32) | crc32(username) 固定算法生成。

### 操作数据包 MSG_OPERATION_REQ

方向: Client -> Server

描述: 客户端发送用户的具体操作。

包体结构:

字段名|数据类型|长度 (字节)|描述
------|-------|------------|--
session_id|uint64_t|8|当前会话 ID，必须与登录时获取的一致。
sequence|uint32_t|4|操作序列号，从 0 开始，每次请求递增 1。用于防止乱序。
operation_code|uint8_t|1|操作码，定义如下：0x01: 上, 0x02: 下, 0x03: 左, 0x04: 右, 0x05: 确认/空格。

### 操作反馈 MSG_FEEDBACK_ACK


方向: Server -> Client

描述: 服务器根据客户端的操作，返回对应的反馈数据（主要是图片）。

包体结构:

字段名|数据类型|长度 (字节)|描述
------|-------|------------|--
session_id|uint64_t|8|当前会话 ID。
sequence|uint32_t|4|对应的操作序列号，客户端需进行校验。
image_checksum|uint32_t|4|图片数据的 CRC32 校验和，用于保证数据完整性。
image_data|byte[]|剩余全部|图片数据。注意: 这是 24位色深 的原始 BMP 像素数据（无文件头），从左到右，从下到上排列。客户端需要根据固定尺寸（例如 64x64 像素）自行重构成像。

