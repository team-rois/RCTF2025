use byteorder::{BigEndian, ReadBytesExt, WriteBytesExt};
use std::io::Cursor;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;

use crate::protocols::*;

/// define message type for recv data
#[derive(Debug)]
pub enum Message {
    HandshakeReq,
    HandshakeAck,
    LoginReq(LoginReqPacket),
    LoginAck(LoginAckPacket),
    OperationReq(OperationReqPacket),
    FeedbackAck {
        packet: FeedbackAckPacket,
        image_data: Vec<u8>,
    },
}

pub struct Connection {
    stream: TcpStream
}

impl Connection {
    
    pub fn new(stream: TcpStream) -> Self{
        Connection{
            stream: stream
        }
    }

    // get data from connection
    pub async fn read_message(&mut self) -> std::io::Result<Option<Message>> {

        // first try to read 8 header data size
        let mut header_self = [0u8; 10];

        if self.stream.read_exact(&mut header_self).await.is_err(){
            // if return error, just return None
            return Ok(None);
        }

        let mut rdr = Cursor::new(&header_self);
        let header = PacketHeader {
            magic: ReadBytesExt::read_u32::<BigEndian>(&mut rdr)?,
            length: ReadBytesExt::read_u32::<BigEndian>(&mut rdr)?,
            msg_type: ReadBytesExt::read_u8(&mut rdr)?,
            reserved: ReadBytesExt::read_u8(&mut rdr)?,
        };

        // check if magic number is correct
        if header.magic != 0xDEADBEEF {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "Invalid magic number"
            ));
        }

        // then try to receive body data
        let mut body_buf = vec![0u8; header.length as usize];
        if header.length > 0 {
            self.stream.read_exact(&mut body_buf).await?;
        }

        // then using enum to create object
        let message = match header.msg_type {
            0x01 => Message::HandshakeReq,
            0x02 => Message::HandshakeAck,
            0x11 => {
                let mut full_buf = header_self.to_vec();
                full_buf.extend_from_slice(&body_buf);
                Message::LoginReq(LoginReqPacket::from_bytes(&full_buf)?)
            },
            0x12 => {
                let mut full_buf = header_self.to_vec();
                full_buf.extend_from_slice(&body_buf);
                Message::LoginAck(LoginAckPacket::from_bytes(&full_buf)?)
            }
            0x21 => {
                let mut full_buf = header_self.to_vec();
                full_buf.extend_from_slice(&body_buf);
                Message::OperationReq(OperationReqPacket::from_bytes(&full_buf)?)
            }
            0x22 => {
                let mut full_buf = header_self.to_vec();
                // we should read extend basic data from body
                let fixed_part_size = std::mem::size_of::<FeedbackAckPacket>() - std::mem::size_of::<PacketHeader>();
                full_buf.extend_from_slice(&&body_buf[..fixed_part_size]);
                let packet = FeedbackAckPacket::from_bytes(&full_buf)?;

                let image_data = body_buf[fixed_part_size..].to_vec();
                Message::FeedbackAck{packet,image_data}
            }
            _ =>{
                return Err(std::io::Error::new(
                    std::io::ErrorKind::InvalidData,
                    format!("Unknown message type {}",header.msg_type),
                ));
            }
        };

        Ok(Some(message))

    }

    // send message data
    pub async fn write_message(&mut self, msg: &Message) -> std::io::Result<()>{
        let bytes = match msg {
            // if message has no body, we will create it by myself
            Message::HandshakeReq => {
                let header = PacketHeader{
                    magic:0xDEADBEEF,
                    length: 0,
                    msg_type:0x1,
                    reserved:0
                };

                let mut wtr = Vec::new();
                
                WriteBytesExt::write_u32::<BigEndian>(&mut wtr,header.magic)?;
                WriteBytesExt::write_u32::<BigEndian>(&mut wtr,header.length)?;
                WriteBytesExt::write_u8(&mut wtr,header.msg_type)?;
                WriteBytesExt::write_u8(&mut wtr,header.reserved)?;
                wtr
            
            }
            Message::HandshakeAck => {
                let header = PacketHeader{
                    magic:0xDEADBEEF,
                    length: 0,
                    msg_type:0x2,
                    reserved:0
                };

                let mut wtr = Vec::new();

                WriteBytesExt::write_u32::<BigEndian>(&mut wtr,header.magic)?;
                WriteBytesExt::write_u32::<BigEndian>(&mut wtr,header.length)?;
                WriteBytesExt::write_u8(&mut wtr,header.msg_type)?;
                WriteBytesExt::write_u8(&mut wtr,header.reserved)?;
                wtr
            }
            Message::LoginReq(packet) => {
                packet.to_bytes()?
            }
            Message::LoginAck(packet) => {
                packet.to_bytes()?
            }

            Message::OperationReq(packet) =>{
                packet.to_bytes()?
            }
            Message::FeedbackAck { packet, image_data } => {
                let mut wtr = packet.to_bytes()?;
                wtr.extend_from_slice(image_data);
                wtr
            }
        };
        self.stream.write_all(&bytes).await
    }
}


/*
 * =====================================================================================
 *
 * 示例用法 (在一个 async main 函数中):
 *
 * async fn main() -> std::io::Result<()> {
 * // 客户端示例
 * let stream = TcpStream::connect("127.0.0.1:8080").await?;
 * let mut connection = Connection::new(stream);
 *
 * // 发送握手请求
 * connection.write_message(&Message::HandshakeReq).await?;
 *
 * // 等待并接收握手确认
 * if let Some(Message::HandshakeAck) = connection.read_message().await? {
 * println!("Handshake successful!");
 * } else {
 * eprintln!("Handshake failed!");
 * }
 *
 * // ... 之后可以发送登录请求等
 *
 * Ok(())
 * }
 *
 * =====================================================================================
 */