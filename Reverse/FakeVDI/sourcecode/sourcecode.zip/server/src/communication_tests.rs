/*
 *  ======================================
 * 
 *  Description: test for communication
 * 
 *  ======================================
*/

#[cfg(test)]
mod tests{
    // import testing module and dependencies
    use crate::communicate::{Connection,Message};
    use crate::protocols::{FeedbackAckPacket, LoginAckPacket, LoginReqPacket, Packet, PacketHeader,MessageType};
    use tokio::io::AsyncWriteExt;
    use tokio::net::{TcpStream, TcpListener};
    use tokio::sync::oneshot;

    // #[repr(u8)]
    // #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    // pub enum MessageType {
    //     HandshakeReqType = 0x01,
    //     HandshakeAckType = 0x02,
    //     LoginReqType     = 0x11,
    //     LoginAckType     = 0x12,
    //     OperationReqType = 0x21,
    //     FeedbackAckType  = 0x22,
    // }

    // testing: LoginReqPacket serialize and unserialize 
    #[test]
    fn test_login_req_roundtrip(){
        let mut username = [0u8; 32];
        let name = b"test_name";
        username[..name.len()].copy_from_slice(name);

        let mut password = [0u8; 32];
        let pass = b"test_password";
        password[..pass.len()].copy_from_slice(pass);

        let packet = LoginReqPacket {
                header:PacketHeader{
                    magic:0xDEADBEEF,
                    length:64, // username + password
                    msg_type:MessageType::LoginReqType as u8,
                    reserved:0,
                    },
                username:username,
                password_hash:password,
        };

        // try to serialize it 
        let bytes = LoginReqPacket::to_bytes(&packet).unwrap();
        // then deserialize it, check if it not changed
        let recon_packet = LoginReqPacket::from_bytes(&bytes).unwrap();

        let origin_magic = packet.header.magic;
        let recon_magic = recon_packet.header.magic;
        assert_eq!(origin_magic, recon_magic);

        let origin_length = packet.header.length;
        let recon_length = recon_packet.header.length;
        assert_eq!(origin_length, recon_length);

        assert_eq!(packet.header.msg_type, recon_packet.header.msg_type);
        assert_eq!(packet.username, recon_packet.username);
        assert_eq!(packet.password_hash, recon_packet.password_hash);

    }

    #[tokio::test]
    async fn test_feedback_ack_variable_length() {
        // create feedback data with image data
        let image_data = vec![0xab,0xcd,0xef,0x12,0x34];
        let fixed_part_size = std::mem::size_of::<FeedbackAckPacket>() - std::mem::size_of::<PacketHeader>();
        let feedback = Message::FeedbackAck{
            packet: FeedbackAckPacket { 
                header : PacketHeader { 
                        magic: 0xDEADBEEF, 
                        length: (fixed_part_size + image_data.len()) as u32, 
                        msg_type: MessageType::FeedbackAckType as u8,
                        reserved: 0 
                    },
                session_id: 0x1111,
                sequence:0x2222,
                image_checksum:0x3333
            },
            image_data: image_data.clone(),
        };

        // monitor network stream
        let mut stream_network = Vec::new();

        let bytes = match &feedback{
            Message::FeedbackAck { packet, image_data } => {
                let mut wtr = packet.to_bytes().unwrap();
                wtr.extend_from_slice(&image_data);
                wtr
            }
            _ =>{
                panic!("Error Msg Type!");
            }
        };

        stream_network.extend_from_slice(&bytes);

        // 2. create tcp stream to monitor send data
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();

        let sender_handler = tokio::spawn(async move {
            let mut stream = TcpStream::connect(addr).await.unwrap();
            let bytes = match &feedback{
                Message::FeedbackAck { packet, image_data } => {
                    let mut wtr = packet.to_bytes().unwrap();
                    wtr.extend_from_slice(&image_data);
                    wtr
                }
                _ => {
                    panic!("Error feedback");
                }
            };
            stream.write_all(&bytes).await.unwrap();
        });

        let (server_stream, _) = listener.accept().await.unwrap();
        let mut connection_reader = Connection::new(server_stream);
        let received_message = connection_reader.read_message().await.unwrap().unwrap();

        // assert check data
        match received_message {
            Message::FeedbackAck { packet, image_data: received_image_data } => {
                let packet_magic = packet.header.magic;
                assert_eq!(packet_magic, 0xDEADBEEF);

                let packet_length = packet.header.length;
                assert_eq!(packet_length, (fixed_part_size + image_data.len()) as u32);

                let packet_session_id = packet.session_id;
                assert_eq!(packet_session_id, 0x1111);

                let packet_sequence = packet.sequence;
                assert_eq!(packet_sequence, 0x2222);

                let packet_image_checksum = packet.image_checksum;
                assert_eq!(packet_image_checksum, 0x3333);

                assert_eq!(received_image_data, image_data);
            }
            _ => panic!("Received message of unexpected type!"),
        }
    }

    #[tokio::test]
    async fn test_full_communication_flow() {
        // println!("try full communication test");
        
        let(tx,rx) = oneshot::channel();

        tokio::spawn(async move {
            let listender = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let addr = listender.local_addr().unwrap();

            tx.send(addr).unwrap();

            let (stream, _) = listender.accept().await.unwrap();
            // panic!("try full communication test");
            let mut connection = Connection::new(stream);

            match connection.read_message().await.unwrap() {
                Some(Message::LoginReq(req)) =>{
                    println!("Server: recv login data");

                    let packet_magic = req.header.magic;
                    assert_eq!(packet_magic, 0xDEADBEEF);
                    assert_eq!(req.header.msg_type, MessageType::LoginReqType as u8);

                    let packet_length = req.header.length;
                    let fixed_part_size  = std::mem::size_of::<LoginReqPacket>() - std::mem::size_of::<PacketHeader>();
                    assert_eq!(packet_length, fixed_part_size  as u32);

                    assert_eq!(req.username[..10], b"test_admin"[..]);
                    assert_eq!(req.password_hash[..8], b"password"[..]);

                    // then we try to send data from server
                    let mut received_username = [0u8; 10];
                    received_username.copy_from_slice(b"test_admin");
                    
                    let ack_packet = Message::LoginAck(LoginAckPacket{
                        header: PacketHeader { 
                            magic: 0xDEADBEEF, 
                            length: (std::mem::size_of::<LoginAckPacket>() - std::mem::size_of::<PacketHeader>()) as u32, 
                            msg_type: MessageType::LoginAckType as u8,  
                            reserved: 0, 
                        },
                        status: 0,
                        session_id: 0xffffffff,
                    });
                    connection.write_message(&ack_packet).await.unwrap();
                    // println!("Receive data and send ack packet");
                }
                _ => {
                    panic!("Receive data from server failed!");
                }
            }
        });

        let addr = rx.await.unwrap();

        // create client stream
        let client_hander = tokio::spawn(async move {
            let stream = TcpStream::connect(addr).await.unwrap();
            let mut connection = Connection::new(stream);
            
            // send LoginReqPacket

            let mut username = [0u8;32];
            username[..10].copy_from_slice(b"test_admin");

            let mut password_hash = [0u8;32];
            password_hash[..8].copy_from_slice(b"password");
            
            let req_packet = Message::LoginReq(LoginReqPacket{
                header: PacketHeader { 
                    magic: 0xDEADBEEF , 
                    length: (std::mem::size_of::<LoginReqPacket>() - std::mem::size_of::<PacketHeader>()) as u32,
                    msg_type: MessageType::LoginReqType as u8, 
                    reserved: 0 as u8
                },
                username:username,
                password_hash:password_hash
            });

            connection.write_message(&req_packet).await.unwrap();
            
            match connection.read_message().await.unwrap() {
                Some(Message::LoginAck(req)) =>{
                    println!("Client: recv loing data");
                    let packet_magic = req.header.magic;
                    assert_eq!(packet_magic, 0xDEADBEEF);
                    assert_eq!(req.header.msg_type, MessageType::LoginAckType as u8);

                    let packet_length = req.header.length;
                    let fixed_part_size  = std::mem::size_of::<LoginAckPacket>() - std::mem::size_of::<PacketHeader>();
                    assert_eq!(packet_length, fixed_part_size  as u32);

                    let req_session_id = req.session_id;
                    assert_eq!(req_session_id, 0xffffffff);
                    assert_eq!(req.status, 0);
                },
                _ => {
                    panic!("Client Recv error message");
                }
            }
        });
        client_hander.await.unwrap();
        
    }
}