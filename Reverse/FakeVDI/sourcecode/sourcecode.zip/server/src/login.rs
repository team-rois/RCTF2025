//! login.rs - CTF Challenge Login Logic
//! Author: Your Name Here
//!
//! This module contains the core login verification logic for the CTF challenge.
//! It is intentionally designed to be confusing for automated analysis tools and
//! to present a multi-step reverse engineering challenge for participants.

// mod m_xxtea;

use crate::m_xxtea::xxtea_encrypt;
use crate::m_rc4::Rc4Simple;
use aes::cipher::{BlockEncryptMut, KeyIvInit};
// --- Crypto library imports ---
use aes::Aes128;
use des::Des;
// use rc4::KeyInit;
// use xxtea::xxtea;
use cbc::cipher::{block_padding::Pkcs7};
use cbc::Encryptor;
use std::arch::asm;

// Define aliases for our block cipher modes for convenience.
// We'll use CBC mode with PKCS#7 padding for both AES and DES.
type Aes128Cbc = Encryptor<Aes128>;
type DesCbc = Encryptor<Des>;

// --- 1. Multiple Encryption Algorithms Implementation ---

/// An enum to represent the different cryptographic algorithms available.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum CryptoAlgorithm {
    Rc4,
    Aes,
    Des,
    Xxtea,
}

fn c_strlen(buf: &[u8]) -> usize {
    buf.iter().position(|&b| b == 0).unwrap_or(buf.len())
}

fn buf_to_str(buf: &[u8]) -> &str {
    let len = buf.iter().position(|&b| b == 0).unwrap_or(buf.len());
    std::str::from_utf8(&buf[..len]).unwrap()
}

/// A generic encryption function that dispatches to the correct implementation.
/// It handles padding for block ciphers automatically.
fn encrypt(algorithm: CryptoAlgorithm, plaintext: &[u8], key: &[u8], iv: Option<&[u8]>) -> Result<Vec<u8>, String> {
    match algorithm {
        CryptoAlgorithm::Aes => {
            let iv = iv.ok_or("AES requires an IV")?;
            let mut buf = plaintext.to_vec();
            let cipher = Aes128Cbc::new_from_slices(key.into(), iv.into()).unwrap();
            // Ok(cipher.encrypt_vec(plaintext))
            // cipher.encrypt_padded_vec_mut::<Pkcs7>(buf);
            // let mut out = allocate_out_vec::<Self>(msg.len());
            buf.resize(plaintext.len() + 16, 0);
            Ok(cipher.encrypt_padded_mut::<Pkcs7>(&mut buf, plaintext.len()).unwrap().to_vec())
        },
        CryptoAlgorithm::Des => {
            let iv = iv.ok_or("DES requires an IV")?;
            let cipher = DesCbc::new_from_slices(key, iv).map_err(|e| e.to_string())?;
            let mut buf = plaintext.to_vec();
            Ok(cipher.encrypt_padded_mut::<Pkcs7>(&mut buf, plaintext.len()).unwrap().to_vec())
        },
        CryptoAlgorithm::Rc4 => {
            // RC4 is a stream cipher and doesn't use padding or IVs.
            // The key size must be valid (e.g., between 1 and 256).
            // let key = GenericArray::from_slice(key);
            // let mut cipher = Rc4::new(key);
            let mut cipher = Rc4Simple::new(key);
            
            let mut buffer = plaintext.to_vec();
            // cipher.apply_keystream(&mut buffer);
            cipher.process(&mut buffer);
            Ok(buffer)
        },
        CryptoAlgorithm::Xxtea => {
            // XXTEA is a block cipher but the crate is simple. It requires a 128-bit (16-byte) key
            // and the data length to be a multiple of 4 bytes. We will enforce our own padding.
            let mut padded_plaintext = plaintext.to_vec();
            let block_size = 4;
            let pad_len = block_size - (padded_plaintext.len() % block_size);
            if pad_len != block_size {
                 padded_plaintext.extend(std::iter::repeat(pad_len as u8).take(pad_len));
            }
            Ok(xxtea_encrypt(plaintext, key))
        }
    }
}


// --- 2 & 3. Struct for storing challenges and their instances ---

/// This structure holds all the necessary components for a single cryptographic challenge.
/// A real solution must match the `correct_ciphertext` after encryption.
pub struct CryptoChallenge {
    pub algorithm: CryptoAlgorithm,
    pub key: Vec<u8>,
    pub iv: Option<Vec<u8>>,
    pub correct_ciphertext: Vec<u8>,
    // pub description: &'static str, // For context
}


fn get_all_challenges() -> Vec<CryptoChallenge> {

    vec![
        // Challenge 0: RC4 (Selected if username.len() % 4 == 0)
        CryptoChallenge {
            algorithm: CryptoAlgorithm::Rc4,
            key: b"CC2T_DgB+pUM5ooF".to_vec(), // 16 bytes
            iv: None,
            correct_ciphertext: hex::decode("80f6650e827d164bdb1ba129543f06ae").unwrap(),
            // description: "A venerable, if insecure, stream cipher.",
        },
        // Challenge 1: AES (Selected if username.len() % 4 == 1)
        CryptoChallenge {
            algorithm: CryptoAlgorithm::Aes,
            key: b"SKygB9j6Odefxq2W".to_vec(), // 16 bytes
            iv: Some(b"FHwewU_SSNSXi3hu".to_vec()), // 16 bytes
            correct_ciphertext: hex::decode("134432739c43fbc956367f49e25b6c0c").unwrap(),
            // description: "The modern standard for symmetric encryption.",
        },
        // Challenge 2: DES (Selected if username.len() % 4 == 2)
        CryptoChallenge {
            algorithm: CryptoAlgorithm::Des,
            key: b"ghGxAvGx".to_vec(), // 8 bytes
            iv: Some(b"FJDBMEYM".to_vec()), // 8 bytes
            correct_ciphertext: hex::decode("1430e877a79866f3e9cd8be92dcc92cd").unwrap(),
            // description: "The classic, but now deprecated, block cipher.",
        },
        // Challenge 3: XXTEA (Selected if username.len() % 4 == 3)
        CryptoChallenge {
            algorithm: CryptoAlgorithm::Xxtea,
            key: b"KVVgwZmzfaa0NXtm".to_vec(), // 16 bytes
            iv: None,
            correct_ciphertext: hex::decode("f0128c11a76c6b31c5195e5079a25b39").unwrap(),
            // description: "A fast and simple block cipher.",
        },
    ]
}

// --- 5. Complex-looking length check ---
#[inline(never)] // Prevent the compiler from optimizing this away
pub fn is_valid_input(input: &[u8]) -> bool {
    let length = c_strlen(input);
    let mut useless_counter: u64 = 0;

    // --- Useless Code Block 1: Pointer arithmetic in an unsafe block ---
    unsafe {
        let ptr = input.as_ptr() as *const u8;
        if length > 0 {
            let _val = std::ptr::read_volatile(ptr.add(length - 1));
            useless_counter += _val as u64;
        }
    }

    // --- Useless Code Block 2: Pointless bitwise operations ---
    let mut mangled_length = length;
    mangled_length ^= 0xDEADBEEF; // Obfuscate
    for i in 0..5 {
        useless_counter = useless_counter.wrapping_add(i);
        mangled_length = mangled_length.rotate_left(3);
    }
    mangled_length = mangled_length.rotate_right(15); // Undo the rotations
    mangled_length ^= 0xDEADBEEF; // De-obfuscate

    // --- Useless Code Block 3: Inline assembly that does nothing important ---
    let mut asm_val = length as u64;
    #[cfg(target_arch = "x86_64")]
    unsafe {
        asm!(
            "mov {0}, {0}", // Move the value into itself (a no-op)
            "add {0}, {1}", // Add the useless counter
            inout(reg) asm_val,
            in(reg) useless_counter,
        );
    }

    // --- The REAL Check ---
    mangled_length == 13
}


pub fn check_username(username: &[u8], password_vec: &Vec<String>) -> Option<String> {

    if username.is_empty()  || password_vec.is_empty(){
        return None;
    }

    let primes: [u64; 16] = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53];
    let seed_part1 = username
        .iter()
        .enumerate()
        .map(|(i, &b)| {
            let p = primes[i % primes.len()];
            let v = (b as u64)
                .wrapping_mul(p)
                .rotate_left(((i * 7 + 3) % 64) as u32)
                ^ ((i as u64).wrapping_mul(i as u64));
            v
        })
        .fold(0u64, |acc, x| acc.wrapping_add(x ^ (acc.rotate_left(13))));

    let letters = username
        .iter()
        .filter(|b| (b'A'..=b'Z').contains(b) || (b'a'..=b'z').contains(b))
        .count() as u64;

    let digits = username
        .iter()
        .filter(|b| (b'0'..=b'9').contains(b))
        .count() as u64;

    let seed_part2 = seed_part1
        .wrapping_mul(0x9E3779B97F4A7C15u64) // golden ratio-ish constant
        .wrapping_add((letters << 8) ^ digits);

    let seed_part3 = username.iter().fold(0u64, |acc, &byte| {
        let c = byte as u64;
        acc.wrapping_mul(31).wrapping_add(c ^ (c.rotate_left(7)))
    });


    let mut seed = seed_part2 ^ seed_part3;
    seed = seed ^ (seed >> 21) ^ (seed.rotate_left(37));

    let transformed: Vec<String> = password_vec.iter().map(|s| s.chars().rev().collect()).collect();

    let wide = seed.wrapping_mul(0x27d4eb2d_u64).wrapping_add(0x165667b_u64);
    let mixed_index = ((wide ^ (wide >> 33)) as usize).wrapping_mul(fn85eb_ca6b_usize());

    let idx = mixed_index % transformed.len();

    let chosen_reversed = &transformed[idx];
    let chosen = chosen_reversed.chars().rev().collect::<String>();

    Some(chosen)
    
}

#[inline(always)]
fn fn85eb_ca6b_usize() -> usize {

    0x85EB_CA6Busize
}


// --- 4, 6, 7. The Main Login Function ---

/// The primary login function for the challenge.
///
/// Args:
/// * `username`: The username provided by the user. Its length must be 13, determines the crypto algorithm.
/// * `password_hash`: The password_hash to be verified. 
///
/// Returns:
/// * `true` if the username/password combination is correct, `false` otherwise.
pub fn login(username: &[u8], password: &[u8]) -> bool {
    
    // Get the list of possible crypto challenges.
    let challenges = get_all_challenges();
    println!("username and password is {:?} {:?}",username,password);
    // Select the encryption algorithm based on the length of the username.
    let challenge_index = c_strlen(username) % challenges.len();
    let selected_challenge = &challenges[challenge_index];
    
    // run the password through the obfuscated length check.
    if !is_valid_input(username) {
            // Fail early if the password length is not 13.
            return false;
    }

    // 6. Encrypt the user-provided password with the selected algorithm's parameters.
    let encryption_result = encrypt(
        selected_challenge.algorithm,
        &username[..c_strlen(username)],
        &selected_challenge.key,
        selected_challenge.iv.as_deref(), // Convert Option<Vec> to Option<&[u8]>
    );


    let user_ciphertext = match encryption_result {
        Ok(data) => data,
        Err(e) => {
            // In a real scenario, we might log this error but not reveal it to the user.
            println!("[ERROR] Encryption failed: {}", e);
            return false;
        }
    };
    
    if user_ciphertext != selected_challenge.correct_ciphertext{
        // login faild
        // println!("Login failed!");
        return false;
    }

    // here we will try to compare password hasdh with origin one
    // if password != selected_challenge.correct_ciphertext {

    // }
    let pass_vec = vec![
            "5f4dcc3b5aa765d61d8327deb882cf99".to_string(),
            "2d152c2e223139101ba9a8fa9b327842".to_string(),
            "eb5af0bb41855770e35ad5458e9e1cce".to_string(),
            "ae33404376da4f440848584e1db00bef".to_string(),
            "c72a9a11f68fba684a32128120d0937d".to_string(),
            "bed128365216c019988915ed3add75fb".to_string(),
            "b60cf8ba7e5dab4b3b6bed78bde1e470".to_string(),
            "f312a7ab2e1078c60452e6ca8611fe3a".to_string(),
            "e2797f6581dacf849a76bb9dd0faf631".to_string(),
            "b46f685f85e0af830d82ddbbe795eff3".to_string(),
            "42d3a1809740b0f17a1ca6b4297e25b1".to_string(),
            "dc647eb65e6711e155375218212b3964".to_string(),
            "9ca81d3d9b7867394ba1c88e4e8dc06b".to_string(),
            "5b01fefcd8fa4f6f13f8b8e59cf19111".to_string(),
            "27218588ab14fb4af52ad2268cf27098".to_string(),
            "8b3135850a15da660c9c43ec7ac75c61".to_string(),
            "a38f3d7bfd0bd06f37abb8c9b581259c".to_string(),
            "24daf135b675026b470b93b117092773".to_string(),
            "221cd58bd865a9ca9afa5d804c1df17b".to_string(),
            "199fa636dd98717dce9052f906fffc4e".to_string(),
            "a414c0e77e372cc49d29494ff9eeaf6c".to_string(),
            "da560a5ec7b3d15402d9aab6cd3584f8".to_string(),
            "d7dd887df2a0f5602af27233d591b20c".to_string(),
            "d86db4beed6275fcd91b41e2a68d6d75".to_string(),
            "1dd8401618e4dff1218232b8c4275d09".to_string(),
            "87e605da7edf5b130f5522e33e3a3b6f".to_string(),
            "8b76e01c871c8067512e3ac3a278a7ab".to_string(),
            "145818cff9512c9803a401bab082c6aa".to_string(),
            "8a02722b5c6f08ab99e1708823aaadfc".to_string(),
            "83d5bb9d9ff38dfce838da104a1c25dd".to_string(),
            "7a7d9f0400e1b8d7bc1ad85faebaf0f1".to_string(),
            "790c7490eb183119a377428f6247bd34".to_string(),
            "a6dcb4030f59d6a725cb0833571fa122".to_string(),
            "84adc11c118d8ea7f72072493da267a7".to_string(),
            "05189dcb0bb5f5587589fd308235e6aa".to_string(),
            "743098b72f6a2a7b8f1de5729ca1ec84".to_string(),
            "ca153c11c9b749f8825d6a12b74af8ca".to_string(),
            "f2e01c045c5403680bd5dab313db525e".to_string(),
            "db3af895903b8579103a822a86e7905d".to_string(),
            "94f67c5a9b0fe37d320cd3fe6b42bc07".to_string(),
            "737975ea76c018c82c173cff5e7f8414".to_string(),
            "107fbc4340708481e8f86333ccccaaa5".to_string(),
            "8747ebaf888ba92fbe7044cac9123ac5".to_string(),
            "508fba2521a7b0b37006c33c5f3ab3db".to_string(),
            "012f6b02afd346c401266eca0dd9d4c2".to_string(),
            "407d51a4d20c2e9fadab1079f093cfed".to_string(),
            "00fcf043b7b9f617482ff83add5cac06".to_string(),
            "d301000b028fc5ba9e88a4763ff08ed3".to_string(),
            "2946a82885e75a7c12cad15ebc432e32".to_string(),
            "0b63f585e9fe79e0c7df664638cd1a8d".to_string(),
            "810f503b06ac47c423a6f430b4551cf3".to_string(),
            "9074907dc5ee241c978f610daab4fae8".to_string(),
            "ed7a95e830e81e604bdf53f4aac79978".to_string(),
            "334faac2d17c2c0e613a380982914f91".to_string(),
            "385341c46299af2a3a6cbe551ac2c57c".to_string(),
            "767f66bbe9f6ff0990f42d04a0123d54".to_string(),
            "383a6b669eae58f1209c389ba4b10a9d".to_string(),
            "f92a554010caf07ab00d1496eacd5193".to_string(),
            "af6cb2471a656dc7ec8682dd97c66b75".to_string(),
            "f12ada976cc834f8f3722983f3a6da5a".to_string(),
            "90b4a121c4ad96269a542e5b64ca961a".to_string(),
            "d599d5292b94aad0f41eb0c1d8fbc31e".to_string(),
            "75ed4e90f68302fe143a550325d29e31".to_string(),
            "ec080a78522b52087efda94a5bd029df".to_string(),
            "e0f46216ed1633db5e4946fb694a686a".to_string(),
            "3deac81ae94603bf18ab1b70f48fa77f".to_string(),
            "50c22ca99176745faaed356bb27a01e6".to_string(),
            "c4323571a6ffc125de95463a1aed1da2".to_string(),
            "67cbfa48b13b37b25e8d990afaef32fe".to_string(),
            "1e0bcedb8b9491e6e05acc1b91abfc04".to_string(),
            "d7fc798bb44d61e2a456cba37689a803".to_string(),
            "806135911a9fa3fd60b39274301625b4".to_string(),
            "97e6a5805d6c39c2a61d2b08dd6a25ae".to_string(),
            "0f5a5e6ff7e3786671a3a360f6f40f47".to_string(),
            "c9f06c6f1fc5e467af75203397728f06".to_string(),
            "710204692ee671e4f9d1d7f3d139b483".to_string(),
            "df8f2336a31d73791d6498201566d7d3".to_string(),
            "2a147f66cf5438b4b5617c9aedfd8086".to_string(),
            "7f205b64d4592eae84b5e5c63a7148d5".to_string(),
            "9f897db324602e57d45a81d915c5aaf5".to_string(),
            "e70159765c6f9c724ff2307d3d89d2ef".to_string(),
            "a84dbd8fd5d469f910a4777d6a2b8925".to_string(),
            "c81ddaed3e937b754b33537489962bca".to_string(),
            "98bde367c6305867714febf21bf7f538".to_string(),
            "f90cbde29eda1ac918db90cd396b0122".to_string(),
            "f206f39efa12989da55b5834d7204383".to_string(),
            "8fea94f65bee888707c6e1545017d2b0".to_string(),
            "e4783ed276521fd998375e1f3fcd73d9".to_string(),
            "3862510e7229c9383b1214a479d09503".to_string(),
            "025da8436de999c0620ff8adc8d0330b".to_string(),
            "d2979d193cbe0b3ec337089ccfd0d971".to_string(),
            "e0a316f283a6053e60ef6b82efce12b3".to_string(),
            "eae279789b2b9e061664bcc0e24cb6f6".to_string(),
            "604795785b94d0389c565bf1229c3ef2".to_string(),
            "28ceb5663bd26d412695546d2f32cff1".to_string(),
            "54ee044f4cf6314b47c2787449fb2343".to_string(),
            "92112e27156c769387874a6bbd56b392".to_string(),
            "8aff1e8cdbdec4efcc19304a1ff677bc".to_string(),
            "0a24858ed6892d4e70edd80cd5f94398".to_string(),
            "2af9270cf6e441ea4104e8604cad9ba4".to_string(),
            "8a9971515fbaa28a04c1b301f8bc4e80".to_string(),
            "4d34e830ba39af8f76a263977e18b887".to_string(),
            "b4eab29618dadca1567e89b7ff978c3f".to_string(),
            "0c3ea24193bbfe3683f30c247ea6360d".to_string(),
            "30f090024bfa81f84197c4fde4c017a1".to_string(),
            "1541b39f64391910ebb3cd6fd77b22a6".to_string(),
            "b5ef22e1314f5adda1b5a11a6a5275c5".to_string(),
            "1411c689b05649c0ae845bccd530737b".to_string(),
            "0014808bd56eb3ff1d02f8bd64cd8956".to_string(),
            "b512b84338831678634b36169dffa16c".to_string(),
            "6387efb6a4d982d7bf2681d10de48f7e".to_string(),
            "ded79f5fac718108afe0445664400cae".to_string(),
            "730e97c77d2a4d2fa523dcd14d458e5f".to_string(),
        ];

    let pick_pass = check_username(&username[..c_strlen(username)], &pass_vec).unwrap();
    return buf_to_str(password) == pick_pass;
    // return password.to_ascii_lowercase() == pick_pass;
}