#[cfg(test)]
mod tests {
    
    use aes::Aes128;
    use des::Des;
    use rc4::{Rc4, KeyInit, StreamCipher};
    // use xxtea::Xxtea;
    // use block_modes::{BlockMode, Cbc};
    // use block_modes::block_padding::Pkcs7;
    use std::arch::asm;

    // Define aliases for our block cipher modes for convenience.
    // We'll use CBC mode with PKCS#7 padding for both AES and DES.
    // type Aes128Cbc = Cbc<Aes128, Pkcs7>;
    // type DesCbc = Cbc<Des, Pkcs7>;

    use crate::login::{login, is_valid_input,check_username};

    const CORRECT_USERNAME:&str = "adm1niStrat0r";
    const CORRECT_PASSHASH:&str = "3deac81ae94603bf18ab1b70f48fa77f";

        #[test]
    fn test_is_valid_input_len_function() {
        assert!(is_valid_input("1234567890123".as_bytes())); // length 13
        assert!(!is_valid_input("123456789012".as_bytes())); // length 12
        assert!(!is_valid_input("12345678901234".as_bytes())); // length 14
        assert!(!is_valid_input("".as_bytes())); // empty
    }

    #[test]
    fn test_login(){

        // here we use our real login username and password
        assert!(login(CORRECT_USERNAME.as_bytes(),CORRECT_PASSHASH.as_bytes()));
    }

    #[test]
    fn test_pick_unique_basic() {
        let pool = vec![
            "apple".to_string(),
            "banana".to_string(),
            "cherry".to_string(),
            "date".to_string(),
            "elder".to_string(),
        ];

        let a1 = check_username("alice".as_bytes(), &pool);
        let a2 = check_username("alice".as_bytes(), &pool);
        assert_eq!(a1, a2);

        let b = check_username("bob".as_bytes(), &pool);
        assert_ne!(a1, b);

        let empty: Vec<String> = vec![];
        assert!(check_username("any".as_bytes(), &empty).is_none());
    }
}