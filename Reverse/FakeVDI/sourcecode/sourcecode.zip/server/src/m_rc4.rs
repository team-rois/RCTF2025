pub struct Rc4Simple {
    s: [u8; 256],
    i: u8,
    j: u8,
}

impl Rc4Simple {
    pub fn new(key: &[u8]) -> Self {
        let mut s = [0u8; 256];
        for i in 0usize..256 { s[i] = i as u8; }
        let mut j: u8 = 0;
        let klen = key.len();
        for i in 0usize..256 {
            let ki = key[i % klen];
            j = j.wrapping_add(s[i]).wrapping_add(ki);
            s.swap(i, j as usize);
        }
        Rc4Simple { s, i: 0, j: 0 }
    }

    /// 就地处理数据（加密或解密）
    pub fn process(&mut self, data: &mut [u8]) {
        for byte in data.iter_mut() {
            self.i = self.i.wrapping_add(1);
            self.j = self.j.wrapping_add(self.s[self.i as usize]);
            self.s.swap(self.i as usize, self.j as usize);
            let t = self.s[self.i as usize].wrapping_add(self.s[self.j as usize]);
            let kbyte = self.s[t as usize];
            *byte ^= kbyte;
        }
    }
}