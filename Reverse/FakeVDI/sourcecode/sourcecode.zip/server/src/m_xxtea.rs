// mod m_xxtea;

const DELTA: u32 = 0x9E3779B9;

fn to_u32_vec(mut data: Vec<u8>, include_length: bool) -> Vec<u32> {
    let n = (data.len() + 3) / 4;
    // pad to multiple of 4
    data.resize(n * 4, 0);
    let mut v = Vec::with_capacity(n + if include_length { 1 } else { 0 });
    for i in 0..n {
        let b0 = data[i * 4] as u32;
        let b1 = data[i * 4 + 1] as u32;
        let b2 = data[i * 4 + 2] as u32;
        let b3 = data[i * 4 + 3] as u32;
        // little-endian
        v.push(b0 | (b1 << 8) | (b2 << 16) | (b3 << 24));
    }
    if include_length {
        v.push((data.len() - (n * 4 - (data.len() % 4) as usize)) as u32); // original length
        // simpler: store original length (before pad). But above calculation ensures original len.
        // Alternative simpler approach: caller passes original length; but this suffices for our use.
    }
    v
}

fn to_u8_vec(v: Vec<u32>, include_length: bool) -> Vec<u8> {
    let mut n = v.len();
    let mut length = n * 4;
    if include_length {
        if n == 0 {
            return vec![];
        }
        // last element stores original length
        let orig_len = v[n - 1] as usize;
        n -= 1;
        length = orig_len;
        let mut out = Vec::with_capacity(length);
        for i in 0..n {
            let x = v[i];
            out.push((x & 0xFF) as u8);
            out.push(((x >> 8) & 0xFF) as u8);
            out.push(((x >> 16) & 0xFF) as u8);
            out.push(((x >> 24) & 0xFF) as u8);
        }
        out.truncate(length);
        out
    } else {
        let mut out = Vec::with_capacity(length);
        for x in v.into_iter() {
            out.push((x & 0xFF) as u8);
            out.push(((x >> 8) & 0xFF) as u8);
            out.push(((x >> 16) & 0xFF) as u8);
            out.push(((x >> 24) & 0xFF) as u8);
        }
        out
    }
}

fn fix_key(key: &[u8]) -> [u32; 4] {
    let mut k = [0u32; 4];
    let mut tmp = [0u8; 16];
    let use_len = key.len().min(16);
    tmp[..use_len].copy_from_slice(&key[..use_len]);
    for i in 0..4 {
        k[i] = (tmp[i * 4] as u32)
            | ((tmp[i * 4 + 1] as u32) << 8)
            | ((tmp[i * 4 + 2] as u32) << 16)
            | ((tmp[i * 4 + 3] as u32) << 24);
    }
    k
}

fn xxtea_encrypt_inplace(v: &mut [u32], k: &[u32; 4]) {
    let n = v.len();
    if n == 0 {
        return;
    }
    if n == 1 {
        // For single-word, XXTEA degenerates; just run a few rounds mixing with key.
        let mut y = v[0];
        let mut sum: u32 = 0;
        let rounds = 6 + 52 / n as u32;
        for _ in 0..rounds {
            sum = sum.wrapping_add(DELTA);
            let e = ((sum >> 2) & 3) as usize;
            let mx = ((y >> 5) ^ (y << 2))
                .wrapping_add((y >> 3) ^ (y << 4))
                ^ (sum ^ y).wrapping_add(k[e] ^ y);
            y = y.wrapping_add(mx);
        }
        v[0] = y;
        return;
    }

    let mut rounds = 6 + 52 / (n as u32);
    let mut sum: u32 = 0;
    let mut z = v[n - 1];
    while rounds > 0 {
        sum = sum.wrapping_add(DELTA);
        let e = ((sum >> 2) & 3) as usize;
        for p in 0..n - 1 {
            let y = v[p + 1];
            let mx = ((z >> 5) ^ (y << 2))
                .wrapping_add((y >> 3) ^ (z << 4))
                ^ (sum ^ y).wrapping_add(k[(p & 3) ^ e] ^ z);
            let new = v[p].wrapping_add(mx);
            z = new;
            v[p] = new;
        }
        // last
        let y = v[0];
        let mx = ((z >> 5) ^ (y << 2))
            .wrapping_add((y >> 3) ^ (z << 4))
            ^ (sum ^ y).wrapping_add(k[((n - 1) & 3) ^ e] ^ z);
        let new = v[n - 1].wrapping_add(mx);
        v[n - 1] = new;
        z = new;
        rounds -= 1;
    }
}

fn xxtea_decrypt_inplace(v: &mut [u32], k: &[u32; 4]) {
    let n = v.len();
    if n == 0 {
        return;
    }
    if n == 1 {
        let mut y = v[0];
        let rounds = 6 + 52 / n as u32;
        let mut sum = rounds.wrapping_mul(DELTA);
        while sum != 0 {
            let e = ((sum >> 2) & 3) as usize;
            let mx = ((y >> 5) ^ (y << 2))
                .wrapping_add((y >> 3) ^ (y << 4))
                ^ (sum ^ y).wrapping_add(k[e] ^ y);
            y = y.wrapping_sub(mx);
            sum = sum.wrapping_sub(DELTA);
        }
        v[0] = y;
        return;
    }

    let mut rounds = 6 + 52 / (n as u32);
    let mut sum = rounds.wrapping_mul(DELTA);
    let mut y = v[0];
    while sum != 0 {
        let e = ((sum >> 2) & 3) as usize;
        for p in (1..n).rev() {
            let z = v[p - 1];
            let mx = ((z >> 5) ^ (y << 2))
                .wrapping_add((y >> 3) ^ (z << 4))
                ^ (sum ^ y).wrapping_add(k[(p & 3) ^ e] ^ z);
            let new = v[p].wrapping_sub(mx);
            y = new;
            v[p] = new;
        }
        let z = v[n - 1];
        let mx = ((z >> 5) ^ (y << 2))
            .wrapping_add((y >> 3) ^ (z << 4))
            ^ (sum ^ y).wrapping_add(k[((0usize) & 3) ^ e] ^ z); // p == 0
        let new = v[0].wrapping_sub(mx);
        v[0] = new;
        y = new;
        sum = sum.wrapping_sub(DELTA);
    }
}

/// Encrypt plaintext with 128-bit (16-byte) key.
/// - `plaintext`: input bytes
/// - `key`: key bytes (pad/truncate to 16 bytes)
/// Returns ciphertext bytes.
pub fn xxtea_encrypt(plaintext: &[u8], key: &[u8]) -> Vec<u8> {
    // convert plaintext to u32 vector and include length as last element
    let mut v = to_u32_vec(plaintext.to_vec(), true);
    let k = fix_key(key);
    xxtea_encrypt_inplace(&mut v, &k);
    to_u8_vec(v, true)
}

/// Decrypt ciphertext with 128-bit key, returns Some(plaintext) or None if invalid.
pub fn xxtea_decrypt(ciphertext: &[u8], key: &[u8]) -> Option<Vec<u8>> {
    // ciphertext should be multiple of 4 bytes and at least 8 bytes (one u32 + length)
    if ciphertext.len() < 8 || ciphertext.len() % 4 != 0 {
        return None;
    }
    let mut v = {
        // convert ciphertext to u32 vec WITHOUT adding length (already encoded)
        let temp = ciphertext.to_vec();
        let n = temp.len() / 4;
        let mut out = Vec::with_capacity(n);
        for i in 0..n {
            let b0 = temp[i * 4] as u32;
            let b1 = temp[i * 4 + 1] as u32;
            let b2 = temp[i * 4 + 2] as u32;
            let b3 = temp[i * 4 + 3] as u32;
            out.push(b0 | (b1 << 8) | (b2 << 16) | (b3 << 24));
        }
        out
    };
    let k = fix_key(key);
    xxtea_decrypt_inplace(&mut v, &k);
    // convert back with include_length=true (last element is original len)
    Some(to_u8_vec(v, true))
}

#[cfg(test)]
mod tests {
    use super::*;

    // #[test]
    // fn test_xxtea_roundtrip() {
    //     let key = b"0123456789ABCDEF";
    //     let tests = [
    //         // b"".to_vec(),
    //         b"a".to_vec(),
    //         b"hello".to_vec(),
    //         b"The quick brown fox jumps over the lazy dog".to_vec(),
    //         vec![0u8; 1],
    //         vec![0u8; 2],
    //         vec![0u8; 3],
    //         vec![0u8; 4],
    //         vec![1u8, 2, 3, 4, 5, 6, 7],
    //     ];
    //     for pt in tests.iter() {
    //         println!("now test case is {:?}", pt);
    //         let ct = xxtea_encrypt(pt, key);
    //         let pt2 = xxtea_decrypt(&ct, key).expect("decrypt failed");
    //         assert_eq!(pt2, *pt);
    //     }
    // }
}