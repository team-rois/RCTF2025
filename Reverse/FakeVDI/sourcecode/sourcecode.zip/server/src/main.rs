mod protocols;
mod communicate;
mod communication_tests;
mod login;
mod login_test;
mod m_xxtea;
mod m_rc4;
mod server_load_img;

use tokio::runtime::Builder;

// use crate::protocols::*;
// use crate::communicate::*;
// use crate::server_load_img::*;
// use crate::login::*;
use crate::server_load_img::run_server;

fn main() {
    let runtime = Builder::new_multi_thread()
        .worker_threads(3)
        .enable_all() 
        .build().unwrap();
    let addr = "0.0.0.0:23333";
    runtime.block_on(async {
        run_server(addr).await;
    })
    
}
