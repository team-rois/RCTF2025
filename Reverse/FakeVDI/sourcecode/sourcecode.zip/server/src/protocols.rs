use byteorder::{BigEndian, ReadBytesExt, WriteBytesExt};
use std::io::{Cursor, Read, Write};

pub trait Packet
where
    Self: Sized,
{
    fn to_bytes(&self) -> std::io::Result<Vec<u8>>;
    fn from_bytes(buf: &[u8]) -> std::io::Result<Self>;
}

// 2.1 通用包头
#[repr(C, packed)]
#[derive(Debug, Clone, Copy)]
pub struct PacketHeader {
    pub magic: u32,
    pub length: u32,
    pub msg_type: u8,
    pub reserved: u8,
}

// 3.3 登录请求包
#[repr(C, packed)]
#[derive(Debug, Clone, Copy)]
pub struct LoginReqPacket {
    pub header: PacketHeader,
    pub username: [u8; 32],
    pub password_hash: [u8; 32],
}

// 3.4 登录确认包
// status:
// 0 -> Success
// 1 -> Login Failed
// 2 -> Not valid package
#[repr(C, packed)]
#[derive(Debug, Clone, Copy)]
pub struct LoginAckPacket {
    pub header: PacketHeader,
    pub status: u8,
    pub session_id: u64,
}

// 3.5 操作请求包
#[repr(C, packed)]
#[derive(Debug, Clone, Copy)]
pub struct OperationReqPacket {
    pub header: PacketHeader,
    pub session_id: u64,
    pub sequence: u32,
    pub operation_code: u8,
}

// 3.6 操作反馈包 (固定部分)
// 同样，image_data 不包含在结构体中
#[repr(C, packed)]
#[derive(Debug, Clone, Copy)]
pub struct FeedbackAckPacket {
    pub header: PacketHeader,
    pub session_id: u64,
    pub sequence: u32,
    pub image_checksum: u32,
}


pub enum MessageType {
    HandshakeReqType = 0x01,
    HandshakeAckType = 0x02,
    LoginReqType     = 0x11,
    LoginAckType     = 0x12,
    OperationReqType = 0x21,
    FeedbackAckType  = 0x22,
}

pub enum OperateType {
    OP_UP = 0x1,
    OP_DOWN = 0x2,
    OP_LEFT = 0x3,
    OP_RIGHT = 0x4,
    OP_ENTER = 0x5,
}

impl TryFrom<u8> for OperateType {
    type Error = ();

    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            0x1 => Ok(OperateType::OP_UP),
            0x2 => Ok(OperateType::OP_DOWN),
            0x3 => Ok(OperateType::OP_LEFT),
            0x4 => Ok(OperateType::OP_RIGHT),
            0x5 => Ok(OperateType::OP_ENTER),
            _ => Err(()),
        }
    }
}
///
/// pub header: PacketHeader,
/// pub username: [u8; 32],
/// pub password_hash: [u8; 32],

impl Packet for LoginReqPacket {
    fn to_bytes(&self) -> std::io::Result<Vec<u8>> {
        let mut wtr = Vec::new();
        // serialize header
        wtr.write_u32::<BigEndian>(self.header.magic)?;
        wtr.write_u32::<BigEndian>(self.header.length)?;
        wtr.write_u8(self.header.msg_type)?;
        wtr.write_u8(self.header.reserved)?;
        // serialize body
        wtr.write_all(&self.username)?;
        wtr.write_all(&self.password_hash)?;

        Ok(wtr)

    }
    fn from_bytes(buf: &[u8]) -> std::io::Result<Self>{
        let mut rdr = Cursor::new(buf);
        let header = PacketHeader {
            magic: rdr.read_u32::<BigEndian>()?,
            length: rdr.read_u32::<BigEndian>()?,
            msg_type: rdr.read_u8()?,
            reserved: rdr.read_u8()?,
        };
        let mut username = [0u8; 32];
        rdr.read_exact(&mut username)?;
        let mut password_hash = [0u8; 32];
        rdr.read_exact(&mut password_hash)?;
        

        Ok(LoginReqPacket {
            header,
            username,
            password_hash,
        })
    }
    
}
// 示例: 如何为 LoginAckPacket 实现序列化和反序列化
impl Packet for LoginAckPacket {
    // 将结构体序列化为网络字节序的字节数组
    fn to_bytes(&self) -> std::io::Result<Vec<u8>> {
        let mut wtr = Vec::new();
        // 序列化 Header
        wtr.write_u32::<BigEndian>(self.header.magic)?;
        wtr.write_u32::<BigEndian>(self.header.length)?;
        wtr.write_u8(self.header.msg_type)?;
        wtr.write_u8(self.header.reserved)?;
        // 序列化 Body
        wtr.write_u8(self.status)?;
        wtr.write_u64::<BigEndian>(self.session_id)?;
        Ok(wtr)
    }

    // 从网络字节序的字节数组反序列化为结构体
    fn from_bytes(buf: &[u8]) -> std::io::Result<Self> {
        let mut rdr = Cursor::new(buf);
        let header = PacketHeader {
            magic: rdr.read_u32::<BigEndian>()?,
            length: rdr.read_u32::<BigEndian>()?,
            msg_type: rdr.read_u8()?,
            reserved: rdr.read_u8()?,
        };
        let status = rdr.read_u8()?;
        let session_id = rdr.read_u64::<BigEndian>()?;

        Ok(LoginAckPacket {
            header,
            status,
            session_id,
        })
    }
}

/// pub session_id: u64,
/// pub sequence: u32,
/// pub operation_code: u8,


impl Packet for OperationReqPacket {
    fn to_bytes(&self) -> std::io::Result<Vec<u8>>
    {
        let mut wtr = Vec::new();
        // 序列化 Header
        wtr.write_u32::<BigEndian>(self.header.magic)?;
        wtr.write_u32::<BigEndian>(self.header.length)?;
        wtr.write_u8(self.header.msg_type)?;
        wtr.write_u8(self.header.reserved)?;
        // 序列化 Body
        wtr.write_u64::<BigEndian>(self.session_id)?;
        wtr.write_u32::<BigEndian>(self.sequence)?;
        wtr.write_u8(self.operation_code)?;
        Ok(wtr)
    }
    fn from_bytes(buf: &[u8]) -> std::io::Result<Self>
    {
        let mut mdr = Cursor::new(buf);
        let header = PacketHeader{
            magic:mdr.read_u32::<BigEndian>()?,
            length: mdr.read_u32::<BigEndian>()?,
            msg_type: mdr.read_u8()?,
            reserved: mdr.read_u8()?
        };

        let session_id = mdr.read_u64::<BigEndian>()?;
        let sequence = mdr.read_u32::<BigEndian>()?;
        let operation_code = mdr.read_u8()?;
        Ok(OperationReqPacket{
            header:header,
            session_id:session_id,
            sequence:sequence,
            operation_code:operation_code
        })
    }
}

///  
/// pub header: PacketHeader,
/// pub session_id: u64,
/// pub sequence: u32,
/// pub image_checksum: u32,
/// 
 
impl Packet for FeedbackAckPacket{
    fn to_bytes(&self) -> std::io::Result<Vec<u8>>{

        let mut wtr = Vec::<u8>::new();
        wtr.write_u32::<BigEndian>(self.header.magic)?;
        wtr.write_u32::<BigEndian>(self.header.length)?;
        wtr.write_u8(self.header.msg_type)?;
        wtr.write_u8(self.header.reserved)?;

        wtr.write_u64::<BigEndian>(self.session_id)?;
        wtr.write_u32::<BigEndian>(self.sequence)?;
        wtr.write_u32::<BigEndian>(self.image_checksum)?;
        Ok(wtr)
    }   

    fn from_bytes(buf: &[u8]) -> std::io::Result<Self>{
        let mut mdr = Cursor::new(buf);
        let header  =  PacketHeader{
            magic:mdr.read_u32::<BigEndian>()?,
            length:mdr.read_u32::<BigEndian>()?,
            msg_type:mdr.read_u8()?,
            reserved:mdr.read_u8()?,
        };

        let session_id = mdr.read_u64::<BigEndian>()?;
        let sequence = mdr.read_u32::<BigEndian>()?;
        let image_checksum = mdr.read_u32::<BigEndian>()?;

        Ok(FeedbackAckPacket { 
            header: header, 
            session_id: session_id, 
            sequence: sequence, 
            image_checksum: image_checksum 
        })
    }
}