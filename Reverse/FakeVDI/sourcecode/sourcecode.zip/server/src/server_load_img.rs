/*
 * =====================================
 * Description:  Load server images
 * =====================================
 */

use crate::communicate::{Connection, Message};
use crate::protocols::{LoginAckPacket, FeedbackAckPacket, PacketHeader, MessageType,OperateType};
use crate::login::login;
use crate::m_rc4::Rc4Simple;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::fs::File;
use std::io::{Read, Write};
use tokio::net::{TcpListener, TcpStream};
// use tokio::sync::Mutex;
use once_cell::sync::Lazy;
use std::sync::Mutex;
// use std::sync::Mutex;
// #[macro_use]
// extern crate lazy_static;

#[derive(Debug)]
struct GameState{
    session_id:u64,
    current_pos:(i32, i32),
    expected_sequence:u32,
}

impl GameState {
    pub fn new(session_id: u64) -> Self{
        GameState { 
            session_id: session_id, 
            current_pos: (0,0), 
            expected_sequence: 0 
        }
    }
}

struct GameWorld {
    image_map: HashMap<(i32,i32),Vec<u8>>
}

pub fn pair_to_u64(x: i32, y: i32) -> u64 {

    let a = (x as i64 as u64) as u64; // sign-preserving cast via i64
    let b = (y as i64 as u64) as u64;
    let mut z = (a << 32) ^ (b & 0xFFFF_FFFFu64);

    z = z.wrapping_add(0x9E3779B97F4A7C15u64);
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58476D1CE4E5B9u64);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D049BB133111EBu64);
    z ^ (z >> 31)
}

struct PathState {
    index: usize,
    prev_pos: (i32, i32),
    started: bool,
}

impl PathState {
    fn new() -> Self {
        Self { index: 0, prev_pos: (0,0), started: false }
    }
}

// lazy_static::lazy_static! {
//     static ref STATE: Mutex<PathState> = Mutex::new(PathState::new());
// }

static STATE: Lazy<Mutex<PathState>> = Lazy::new(|| Mutex::new(PathState::new()));

fn dir_hash(dx: i32, dy: i32, step: usize) -> u64 {
    let a = dx as u64;
    let b = dy as u64;
    (a << 32) ^ b ^ ((step as u64).wrapping_mul(0x9E3779B97F4A7C15))
}


// 方向列表（题目路径）
const DIRS: [(i32,i32); 12] = [
    (1,0), // (1,0)
    (-1,0), // (0,0)
    (-1,0), // (-1,0)
    (1,0), // (0,0)
    (0,1), // (0,1)
    (1,0), // (1,1)
    (1,0), // (2,1) 
    (0,1), // (2,2) 
    (0,1), // (2,3) 
    (1,0), // (3,3) 
    (0,-1), // (3,2) 
    (-1,0), // (2,2)
];

static DIR_HASHES: Lazy<Vec<u64>> = Lazy::new(|| {
    DIRS.iter()
        .enumerate()
        .map(|(i, (dx, dy))| dir_hash(*dx, *dy, i))
        .collect()
});

// lazy_static::lazy_static! {
//     static ref DIR_HASHES: Vec<u64> = DIRS.iter()
//         .enumerate()
//         .map(|(i,(dx,dy))| dir_hash(*dx,*dy,i))
//         .collect();
// }


pub fn step_path(current_pos: (i32, i32)) -> bool {
    let mut state = STATE.lock().unwrap();

    if !state.started {
        if current_pos == (0,0) {
            state.started = true;
            state.prev_pos = current_pos;
            return true;
        } else {
            return false;
        }
    }

    let dx = current_pos.0 - state.prev_pos.0;
    let dy = current_pos.1 - state.prev_pos.1;
    let dir_h = dir_hash(dx, dy, state.index);

    if state.index < DIR_HASHES.len() && dir_h == DIR_HASHES[state.index] {
        // println!("current! now is {:?}", state.index);
        state.index += 1;
        state.prev_pos = current_pos;
        true
    } else {
        // println!("error move");
        if current_pos == (0,0) {
            *state = PathState::new();
            true
        } else {
            false
        }
    }
}

pub fn is_finished() -> bool {
    let state = STATE.lock().unwrap();
    state.index == DIR_HASHES.len()
}

impl GameWorld {

    pub fn load_img_with_coordinate(x: i32, y: i32) -> Result<Vec<u8>,std::io::Error> {

        // [TODO]: using coordinate to generate image name
        let filename = format!("res/{:016x}",pair_to_u64(x,y));
        println!("filename is {:?}",filename);
        let mut file = File::open(&filename)?;
        let mut buffer = Vec::new();
        file.read_to_end(&mut buffer)?;
        if true {
            Ok(buffer)
        } else {
                Err(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                format!("Image for coordinate ({}, {}) not found, feature not implemented.", x, y)
            ))
        }
    }

    pub fn new() -> Self {
        let mut image_map = HashMap::new();
        // [TODO]: we will use coordinate to load image
        // load_image_from_res();

        let coordinates_to_load = [
            (0, 0), 
            (1, 0), 
            (-1, 0),
            (0, 1), 
            (0, -1),
        ];

        for &(x, y) in &coordinates_to_load{
            match GameWorld::load_img_with_coordinate(x, y) {
                Ok(img) => {
                    image_map.insert((x,y), img);
                }
                Err(_e) => {
                    // could not load image
                    // here we try to load default image 
                    // [TODO]: add hints
                    image_map.insert((x,y), vec![0]);
                }
            }
        }
        GameWorld { image_map }
    }

    pub fn save_decrypted_image(&self, buffer: &[u8], path: &str) -> std::io::Result<()> {
        let mut file = File::create(path)?;
        file.write_all(buffer)?;
        // file.write_all(buffer)?;
        Ok(())
    }
    // if position not exist , load default image
    pub fn get_image_for_position(&self, pos:(i32, i32),session_id:u64) -> Vec<u8> {
        
        let mut image = self.image_map.get(&pos).cloned().unwrap_or_else(|| vec![0]);
        
        if image == vec![0] {
            match GameWorld::load_img_with_coordinate(pos.0, pos.1) {
                Ok(img) => {
                    // self.image_map.insert(pos, img.clone());
                    image = img;
                }
                Err(_e) => {
                    // self.image_map.insert(pos, vec![0]);
                }
            }
        }

        let mut cipher = Rc4Simple::new(&session_id.to_le_bytes());
        let mut buffer = image.to_vec();
        // cipher.apply_keystream(&mut buffer);
        cipher.process(&mut buffer);
        // [TODO]:remove here
        // println!("buffer length is {:?}",buffer.len());
        // self.save_decrypted_image(&buffer, "temp.bmp").expect("Failed to save temp.bmp");
        buffer
        
    }

    
}



/// run_sever
/// arguments: 
/// addr: &str , like "127.0.0.1:23333"
pub async fn run_server(addr: &str) -> Result<(), Box<dyn std::error::Error>> {

    let listener = TcpListener::bind(addr).await.unwrap();
    // let addr = listener.local_addr().unwrap();
    println!("listen to {}", addr);

    let game_world = Arc::new(GameWorld::new());

    loop {
        let(stream, client_addr) = listener.accept().await.unwrap();
        println!("Recv connection from {}", client_addr);

        let world_clone = game_world.clone();

        tokio::spawn(async move {
            if let Err(e) = handle_client(stream ,client_addr, world_clone).await {
                eprintln!("client {} error {}",client_addr, e);
            };
        });
    };

}

fn validate_header(header: &PacketHeader) -> Result<(), &'static str> {

        if header.magic != 0xDEADBEEF {
            return Err("Error magic number");
        }

        if header.reserved != 0{
            return Err("Error reserved value");
        }

        return Ok(());
}

pub fn hash_username_password(username: &[u8; 32], password: &[u8; 32]) -> u64 {
     
    let mut hash: u64 = 0xcbf29ce484222325;
     
    for &b in username.iter() {
        if b == 0 { break; } 
        hash ^= b as u64;
        hash = hash.wrapping_mul(0x100000001b3); 
    }

    // 处理 password
    for &b in password.iter() {
        if b == 0 { break; }
        hash ^= b as u64;
        hash = hash.wrapping_mul(0x100000001b3);
    }

    hash
}


// here we add a strict
// client port must come from 33332
async fn handle_client(stream: TcpStream, addr: SocketAddr, world: Arc<GameWorld>) -> Result<(), Box<dyn std::error::Error>> {


    let mut connect = Connection::new(stream);
    // 1. bypass port strict
    
    
    let port = addr.port();
    if port != 33332 {
        return Err("Invalid magic number".into());
    }

    // ---- handshake ----
    match connect.read_message().await? {
        Some(Message::HandshakeReq) => {
            connect.write_message(&Message::HandshakeAck).await?;
        }
        _ => {
            return Err("Step failed".into());
        }
    }

    // ---- login steps ----
    let session_id = match connect.read_message().await? {
        Some(Message::LoginReq(msg)) => {
            if let Err(e) = validate_header(&msg.header) {
                eprintln!("login failed {}", e);
                return Err(e.into());
            }

            if !login(&msg.username,&msg.password_hash) {
                return Err("Session failed".into());
            }

            // calculate new session_id
            // correct session_id 4659270777073628827
            let session_id = hash_username_password(&msg.username,&msg.password_hash);
            // ack message 
            let ack = Message::LoginAck(LoginAckPacket { 
                header: PacketHeader { 
                    magic: 0xdeadbeef, 
                    length: (std::mem::size_of::<LoginAckPacket>() - std::mem::size_of::<PacketHeader>()) as u32, 
                    msg_type: MessageType::LoginAckType as u8, 
                    reserved: 0 
                }, 
                status: 0, 
                session_id: session_id 
            });
            connect.write_message(&ack).await?;
            session_id
        }
        _ => {
            return Err("Session failed".into());
        }
    };

    // ---- create game state ----
    let mut game_state = GameState::new(session_id);
    // ---- load game world with session_id


    // ---- 2. Game loop state
    loop{
        println!("waiting for game state");
        match connect.read_message().await? {
            Some(Message::OperationReq(op_req)) => {
                if let Err(_e) = validate_header(&op_req.header) {
                    eprintln!("operation header not valid");
                    break;
                }

                // print
                if game_state.session_id != op_req.session_id {
                    eprintln!("not valid session!");
                    break;
                }

                let now_seq = op_req.sequence;
                if game_state.expected_sequence != op_req.sequence {
                    eprintln!("not valid sequence! excepted {}, but we get {}", game_state.expected_sequence, now_seq);
                    break;
                }

                // try to do with request
                match OperateType::try_from(op_req.operation_code) {
                    Ok(OperateType::OP_UP) => { game_state.current_pos.1 += 1; }
                    Ok(OperateType::OP_DOWN) => {game_state.current_pos.1 -= 1; }
                    Ok(OperateType::OP_LEFT) => {game_state.current_pos.0 -= 1; }
                    Ok(OperateType::OP_RIGHT) => {game_state.current_pos.0 += 1; }
                    Ok(OperateType::OP_ENTER) => {game_state.current_pos.0 += 0; }
                    _ => {}
                }

                // here we add one check function, if check success, we will print
                // "You conquered the grid of 81 trials."
                if step_path(game_state.current_pos) && is_finished() {
                    println!("You conquered the grid of 81 trials!");
                }
                game_state.expected_sequence += 1;

                // send response to feedback
                let image_data = world.get_image_for_position(game_state.current_pos, session_id);
                // [TODO]:Remove here
                // we will dump the result
                println!("image name is {:?}", pair_to_u64(game_state.current_pos.0, game_state.current_pos.1));
                println!("image data length is {:?}",image_data.len());
                let feedback = Message::FeedbackAck { 
                    packet: FeedbackAckPacket { 
                        header: PacketHeader { 
                            magic: 0xdeadbeef, 
                            length: (std::mem::size_of::<FeedbackAckPacket>() - std::mem::size_of::<PacketHeader>() + image_data.len()) as u32,
                            msg_type: MessageType::FeedbackAckType as u8, 
                            reserved: 0 
                        }, 
                        session_id: game_state.session_id, 
                        sequence: op_req.sequence, 
                        // TODO: here we will calc the checksum of the image
                        image_checksum: 0 }, 
                    image_data: image_data 
                };
                // println!("here we send back {:?}", feedback);
                connect.write_message(&feedback).await?;
                // println!("send the new position {:?}", game_state.current_pos);

            }
            None => {
                println!("disconnect it");
                break;
            }
            _ => {
                eprintln!("error");
                break;
            }
        }
    }

    return Ok(());
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hash_username_password() {
        let name = b"adm1niStrat0r";
        let mut username: [u8;32] = [0;32];
        username[..name.len()].copy_from_slice(name);

        let hash = b"3deac81ae94603bf18ab1b70f48fa77f";
        let mut password_hash: [u8;32] = [0;32];
        password_hash[..hash.len()].copy_from_slice(hash);

        let session_id = hash_username_password(&username, &password_hash);
        // 4659270777073628827
        assert_eq!(4659270777073628827, session_id);
    }

    #[test]
    fn test_pair_to_u64() {
        let a = pair_to_u64(1, 2);
        let b = pair_to_u64(1, 2);
        let c = pair_to_u64(2, 1);
        assert_eq!(a, b);
        assert_ne!(a, c);
        // (0,0)->(1,0)->(0,0)->(-1,0)->(0,0)->(0,1)->(1,1)->(2,1)->(2,2)->(2,3)->(3,3)->(3,2)->(2,2)
            let coordinates_to_load = [
            (0, 0), 
            (1, 0), 
            (0, 0),
            (-1, 0),
            (0, 0), 
            (0, 1),
            (1, 1),
            (2,1),
            (2,2),
            (2,3),
            (3,3),
            (3,2),
            (2,2)
        ];

// coord (0, 0) now file name is e220a8397b1dcdaf
// coord (1, 0) now file name is c42c5a1aa3820138
// coord (0, 0) now file name is e220a8397b1dcdaf
// coord (-1, 0) now file name is 219fc13d6bc5b015
// coord (0, 0) now file name is e220a8397b1dcdaf
// coord (0, 1) now file name is 910a2dec89025cc1
// coord (1, 1) now file name is 204391a6fd59956f
// coord (2, 1) now file name is c4858308e5949c49
// coord (2, 2) now file name is a8391e4528c2a97f
// coord (2, 3) now file name is ee1914ea7f5851a7
// coord (3, 3) now file name is 26acb5b475148578
// coord (3, 2) now file name is 0999e0d6abbeb2dd
// coord (2, 2) now file name is a8391e4528c2a97f

        for each_ord in coordinates_to_load {

            println!("coord {:?} now file name is {:016x}",each_ord, pair_to_u64(each_ord.0,each_ord.1));
            
        }
    }
}